import math
import random
import sys
import pygame

from levels_data import CHARACTERS, WORLDS
from sound_engine import SoundEngine

# Resolución lógica interna (escalada automáticamente a cualquier pantalla o Pantalla Completa)
BASE_W = 1280
BASE_H = 720
FPS = 60
GRAVITY = 0.68


class Platform:
    def __init__(self, x, y, w, h, kind="solid"):
        self.rect = pygame.Rect(x, y, w, h)
        self.start_x = float(x)
        self.start_y = float(y)
        self.kind = kind
        self.dx = 0.0
        self.dy = 0.0
        self.phase = random.uniform(0, math.pi * 2)

    def update(self, tick: int):
        prev_x, prev_y = self.rect.x, self.rect.y
        if self.kind == "moving_h":
            target_x = self.start_x + math.sin(tick * 0.035 + self.phase) * 95
            self.rect.x = int(round(target_x))
        elif self.kind == "moving_v":
            target_y = self.start_y + math.sin(tick * 0.035 + self.phase) * 80
            self.rect.y = int(round(target_y))
        self.dx = self.rect.x - prev_x
        self.dy = self.rect.y - prev_y


class Enemy:
    def __init__(self, x, y, min_x, max_x, kind="walker"):
        self.kind = kind
        w, h = (40, 36) if kind != "flyer" else (44, 32)
        self.rect = pygame.Rect(x, y, w, h)
        self.start_y = float(y)
        self.min_x = min_x
        self.max_x = max_x
        self.vx = 2.1 if kind == "walker" else (3.6 if kind == "fast" else 2.5)
        self.alive = True
        self.phase = random.uniform(0, math.pi * 2)

    def update(self, tick: int):
        if not self.alive:
            return
        self.rect.x += int(round(self.vx))
        if self.rect.left <= self.min_x:
            self.rect.left = self.min_x
            self.vx = abs(self.vx)
        elif self.rect.right >= self.max_x:
            self.rect.right = self.max_x
            self.vx = -abs(self.vx)

        if self.kind == "flyer":
            self.rect.y = int(self.start_y + math.sin(tick * 0.06 + self.phase) * 28)


class Particle:
    def __init__(self, x, y, color, vx=None, vy=None, life=28):
        self.x = float(x)
        self.y = float(y)
        self.vx = vx if vx is not None else random.uniform(-3.5, 3.5)
        self.vy = vy if vy is not None else random.uniform(-5.5, -1.0)
        self.color = color
        self.life = life
        self.max_life = life
        self.size = random.randint(4, 8)

    def update(self):
        self.x += self.vx
        self.y += self.vy
        self.vy += 0.22
        self.life -= 1

    def draw(self, surf, cam_x):
        if self.life > 0:
            alpha_scale = self.life / self.max_life
            r = max(2, int(self.size * alpha_scale))
            pygame.draw.circle(surf, self.color, (int(self.x - cam_x), int(self.y)), r)


class Player:
    def __init__(self, player_num: int, char_data: dict, spawn_x: int, spawn_y: int):
        self.player_num = player_num
        self.char = char_data
        self.rect = pygame.Rect(spawn_x, spawn_y, 38, 52)
        self.vx = 0.0
        self.vy = 0.0
        self.on_ground = False
        self.facing = 1
        self.max_hp = char_data["max_hp"]
        self.hp = self.max_hp
        self.alive = True
        self.invuln = 0
        self.score = 0
        self.riding_platform = None

    def respawn_near(self, target_x: int, target_y: int):
        self.rect.x = target_x
        self.rect.y = target_y - 60
        self.vx = 0.0
        self.vy = 0.0
        self.hp = max(2, self.max_hp - 1)
        self.alive = True
        self.invuln = 90

    def update(self, keys, platforms, world_length: int, friction: float, sound: SoundEngine, particles: list):
        if not self.alive:
            return

        if self.invuln > 0:
            self.invuln -= 1

        # Controles separados por jugador
        if self.player_num == 1:
            left = keys[pygame.K_a]
            right = keys[pygame.K_d]
            jump = keys[pygame.K_w]
        else:
            left = keys[pygame.K_LEFT]
            right = keys[pygame.K_RIGHT]
            jump = keys[pygame.K_UP]

        # Movimiento horizontal con fricción según bioma (hielo vs tierra)
        accel = self.char["speed"] * (1.0 - friction) * 2.2
        if left:
            self.vx -= accel
            self.facing = -1
        if right:
            self.vx += accel
            self.facing = 1

        self.vx *= friction
        max_s = self.char["speed"]
        if abs(self.vx) > max_s:
            self.vx = max_s * (1 if self.vx > 0 else -1)
        if abs(self.vx) < 0.08:
            self.vx = 0.0

        # Salto
        if jump and self.on_ground:
            self.vy = self.char["jump"]
            self.on_ground = False
            self.riding_platform = None
            sound.play_sfx("jump")
            for _ in range(7):
                particles.append(Particle(self.rect.centerx, self.rect.bottom, (240, 240, 240), vy=random.uniform(-2, 0.5), life=18))

        # Arrastre si está encima de plataforma móvil
        if self.on_ground and self.riding_platform is not None:
            self.rect.x += int(self.riding_platform.dx)
            self.rect.y += int(self.riding_platform.dy)

        # Aplicar movimiento X y colisiones
        self.rect.x += int(round(self.vx))
        if self.rect.left < 0:
            self.rect.left = 0
            self.vx = 0
        if self.rect.right > world_length:
            self.rect.right = world_length
            self.vx = 0

        for plat in platforms:
            if self.rect.colliderect(plat.rect):
                if self.vx > 0:
                    self.rect.right = plat.rect.left
                elif self.vx < 0:
                    self.rect.left = plat.rect.right
                self.vx = 0

        # Aplicar gravedad y colisiones Y
        self.vy = min(self.vy + GRAVITY, 18.0)
        self.rect.y += int(round(self.vy))
        self.on_ground = False
        self.riding_platform = None

        for plat in platforms:
            if self.rect.colliderect(plat.rect):
                if self.vy > 0:
                    self.rect.bottom = plat.rect.top
                    self.vy = 0
                    self.on_ground = True
                    self.riding_platform = plat
                elif self.vy < 0:
                    self.rect.top = plat.rect.bottom
                    self.vy = 0

    def take_damage(self, amount: int, sound: SoundEngine, particles: list):
        if not self.alive or self.invuln > 0:
            return
        self.hp -= amount
        self.invuln = 75
        self.vy = -9.5
        sound.play_sfx("hurt")
        for _ in range(14):
            particles.append(Particle(self.rect.centerx, self.rect.centery, (255, 70, 70)))
        if self.hp <= 0:
            self.hp = 0
            self.alive = False

    def draw(self, surf: pygame.Surface, cam_x: float, font_tiny: pygame.font.Font):
        if not self.alive:
            return
        if self.invuln > 0 and (self.invuln // 4) % 2 == 0:
            return

        x = int(self.rect.x - cam_x)
        y = int(self.rect.y)
        w, h = self.rect.w, self.rect.h

        # Cuerpo
        pygame.draw.rect(surf, self.char["color"], (x + 4, y + 14, w - 8, h - 18), border_radius=8)
        # Cabeza
        pygame.draw.rect(surf, (255, 220, 185), (x + 6, y + 4, w - 12, 18), border_radius=6)
        # Gorra / Casco
        pygame.draw.rect(surf, self.char["hat_color"], (x + 3, y, w - 6, 9), border_radius=4)
        vis_x = x + 16 if self.facing == 1 else x
        pygame.draw.rect(surf, self.char["hat_color"], (vis_x, y + 5, 22, 4), border_radius=2)
        # Ojo
        eye_x = x + 23 if self.facing == 1 else x + 10
        pygame.draw.circle(surf, self.char["eye_color"], (eye_x, y + 13), 3)
        # Botas
        pygame.draw.rect(surf, (45, 35, 35), (x + 5, y + h - 7, 11, 7), border_radius=3)
        pygame.draw.rect(surf, (45, 35, 35), (x + w - 16, y + h - 7, 11, 7), border_radius=3)

        # Etiqueta J1 / J2
        tag = font_tiny.render(f"J{self.player_num}", True, (255, 255, 255))
        tag_bg = pygame.Rect(x + w // 2 - 13, y - 20, 26, 16)
        pygame.draw.rect(surf, (20, 20, 30), tag_bg, border_radius=4)
        surf.blit(tag, (tag_bg.x + 5, tag_bg.y + 1))


class ChronoJumpersGame:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption("CHRONO JUMPERS: MULTIVERSO - Python Edition")

        self.fullscreen = True
        self.screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
        self.canvas = pygame.Surface((BASE_W, BASE_H))
        self.clock = pygame.time.Clock()
        self.sound = SoundEngine()

        self.font_title = pygame.font.SysFont("arial", 54, bold=True)
        self.font_large = pygame.font.SysFont("arial", 34, bold=True)
        self.font_med = pygame.font.SysFont("arial", 22, bold=True)
        self.font_small = pygame.font.SysFont("arial", 17)
        self.font_tiny = pygame.font.SysFont("arial", 13, bold=True)

        self.state = "MENU"  # MENU, PLAYING, LEVEL_CLEAR, GAME_OVER, VICTORY
        self.num_players = 2
        self.p1_char_idx = 0
        self.p2_char_idx = 1
        self.world_idx = 0
        self.tick = 0
        self.cam_x = 0.0

        self.players = []
        self.platforms = []
        self.spikes = []
        self.enemies = []
        self.coins = []
        self.hearts = []
        self.particles = []
        self.goal_rect = pygame.Rect(0, 0, 56, 110)

    def toggle_fullscreen(self):
        self.fullscreen = not self.fullscreen
        if self.fullscreen:
            self.screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
        else:
            self.screen = pygame.display.set_mode((1280, 720), pygame.RESIZABLE)

    def start_campaign(self):
        self.world_idx = 0
        self.players = [
            Player(1, CHARACTERS[self.p1_char_idx], 80, 500),
        ]
        if self.num_players == 2:
            self.players.append(Player(2, CHARACTERS[self.p2_char_idx], 140, 500))
        self.load_world(0)
        self.state = "PLAYING"

    def load_world(self, idx: int):
        self.world_idx = idx
        w_data = WORLDS[idx]
        self.cam_x = 0.0
        self.particles.clear()

        self.platforms = [Platform(*p) for p in w_data["platforms"]]
        self.spikes = [pygame.Rect(*s) for s in w_data["spikes"]]
        self.enemies = [Enemy(*e) for e in w_data["enemies"]]
        self.coins = [pygame.Rect(cx, cy, 22, 22) for cx, cy in w_data["coins"]]
        self.hearts = [pygame.Rect(hx, hy, 26, 24) for hx, hy in w_data["hearts"]]
        gx, gy = w_data["goal"]
        self.goal_rect = pygame.Rect(gx, gy, 58, 110)

        # Al iniciar o pasar de nivel, todos los jugadores reviven y aparecen al inicio del mundo
        for i, p in enumerate(self.players):
            p.alive = True
            p.hp = p.max_hp
            p.rect.x = 80 + i * 55
            p.rect.y = 500
            p.vx = 0
            p.vy = 0
            p.invuln = 60

        self.sound.play_music(idx)

    def draw_gradient_bg(self, top_col, bot_col):
        for y in range(0, BASE_H, 4):
            ratio = y / BASE_H
            r = int(top_col[0] + (bot_col[0] - top_col[0]) * ratio)
            g = int(top_col[1] + (bot_col[1] - top_col[1]) * ratio)
            b = int(top_col[2] + (bot_col[2] - top_col[2]) * ratio)
            pygame.draw.rect(self.canvas, (r, g, b), (0, y, BASE_W, 4))

    def draw_world_scenery(self, w_data: dict):
        self.draw_gradient_bg(w_data["sky_top"], w_data["sky_bottom"])

        # Detalles atmosféricos por bioma
        if self.world_idx == 2:  # Cristales brillantes en el fondo
            for i in range(14):
                sx = (i * 290 - int(self.cam_x * 0.25)) % (BASE_W + 200) - 100
                sy = 110 + (i % 4) * 65
                pygame.draw.polygon(self.canvas, (140, 230, 255), [(sx, sy - 14), (sx + 9, sy), (sx, sy + 14), (sx - 9, sy)])
        elif self.world_idx == 3:  # Aurora boreal y copos de nieve
            pygame.draw.ellipse(self.canvas, (70, 235, 175), (140, 55, 980, 75))
            for i in range(35):
                nx = (i * 97 + self.tick * 2 - int(self.cam_x * 0.5)) % BASE_W
                ny = (i * 53 + self.tick * 3) % BASE_H
                pygame.draw.circle(self.canvas, (255, 255, 255), (nx, ny), 3)
        elif self.world_idx == 4:  # Chispas volcánicas
            for i in range(28):
                fx = (i * 113 + int(math.sin(self.tick * 0.05 + i) * 25)) % BASE_W
                fy = BASE_H - ((i * 47 + self.tick * 3) % BASE_H)
                pygame.draw.circle(self.canvas, (255, 140, 40), (fx, fy), 3)

        # Montañas parallax
        hill_col = w_data["hill_color"]
        for i in range(-1, 8):
            hx = i * 380 - int(self.cam_x * 0.35) % 380
            pts = [(hx, BASE_H), (hx + 190, 340 + (i % 2) * 60), (hx + 380, BASE_H)]
            pygame.draw.polygon(self.canvas, hill_col, pts)

    def draw_platforms_and_hazards(self, w_data: dict):
        for plat in self.platforms:
            rx = plat.rect.x - int(self.cam_x)
            if rx + plat.rect.w < -50 or rx > BASE_W + 50:
                continue
            r = pygame.Rect(rx, plat.rect.y, plat.rect.w, plat.rect.h)

            if plat.kind == "ice":
                pygame.draw.rect(self.canvas, (150, 225, 250), r, border_radius=6)
                pygame.draw.rect(self.canvas, (235, 252, 255), (r.x, r.y, r.w, 12), border_radius=4)
            elif plat.kind in ("moving_h", "moving_v"):
                pygame.draw.rect(self.canvas, (215, 155, 55), r, border_radius=8)
                pygame.draw.rect(self.canvas, (255, 220, 110), r, width=3, border_radius=8)
            else:
                pygame.draw.rect(self.canvas, w_data["ground_body"], r, border_radius=6)
                pygame.draw.rect(self.canvas, w_data["ground_top"], (r.x, r.y, r.w, 16), border_radius=5)

        # Pinchos / Cactus / Cristales afilados
        for sp in self.spikes:
            sx = sp.x - int(self.cam_x)
            if sx + sp.w < -40 or sx > BASE_W + 40:
                continue
            num_teeth = max(2, sp.w // 20)
            tw = sp.w / num_teeth
            spike_col = (50, 175, 70) if self.world_idx == 1 else (235, 65, 85)
            for t in range(num_teeth):
                tx = sx + t * tw
                pts = [(tx, sp.bottom), (tx + tw / 2, sp.top), (tx + tw, sp.bottom)]
                pygame.draw.polygon(self.canvas, spike_col, pts)

        # Peligro inferior (Lava / Agua / Arenas movedizas)
        hz = w_data["hazard_type"]
        if hz in ("lava", "water", "quicksand"):
            hz_col = (245, 75, 25) if hz == "lava" else ((45, 145, 240) if hz == "water" else (215, 165, 75))
            wave_off = int(math.sin(self.tick * 0.12) * 5)
            pygame.draw.rect(self.canvas, hz_col, (0, BASE_H - 26 + wave_off, BASE_W, 36))

    def draw_collectibles_and_goal(self):
        # Monedas
        for c in self.coins:
            cx = c.centerx - int(self.cam_x)
            bob = int(math.sin(self.tick * 0.1 + c.x * 0.05) * 4)
            pygame.draw.circle(self.canvas, (255, 215, 40), (cx, c.centery + bob), 11)
            pygame.draw.circle(self.canvas, (255, 245, 160), (cx - 3, c.centery + bob - 3), 4)

        # Corazones para revivir o curar
        for h in self.hearts:
            hx = h.centerx - int(self.cam_x)
            bob = int(math.sin(self.tick * 0.12 + h.x * 0.03) * 5)
            cy = h.centery + bob
            pygame.draw.circle(self.canvas, (255, 65, 115), (hx - 5, cy - 3), 7)
            pygame.draw.circle(self.canvas, (255, 65, 115), (hx + 5, cy - 3), 7)
            pygame.draw.polygon(self.canvas, (255, 65, 115), [(hx - 12, cy - 1), (hx + 12, cy - 1), (hx, cy + 11)])

        # Portal dimensional de meta
        gx = self.goal_rect.x - int(self.cam_x)
        gy = self.goal_rect.y
        pygame.draw.ellipse(self.canvas, (90, 240, 255), (gx, gy, self.goal_rect.w, self.goal_rect.h))
        inner_pulse = int(math.sin(self.tick * 0.15) * 6)
        pygame.draw.ellipse(
            self.canvas,
            (225, 255, 255),
            (gx + 10 - inner_pulse // 2, gy + 14, self.goal_rect.w - 20 + inner_pulse, self.goal_rect.h - 28),
        )
        lbl = self.font_tiny.render("META", True, (255, 255, 255))
        self.canvas.blit(lbl, (gx + 12, gy - 20))

    def draw_enemies(self):
        for en in self.enemies:
            if not en.alive:
                continue
            ex = en.rect.x - int(self.cam_x)
            ey = en.rect.y
            if ex + en.rect.w < -40 or ex > BASE_W + 40:
                continue

            if en.kind == "flyer":
                # Enemigo volador con alas
                wing_y = ey + 8 + int(math.sin(self.tick * 0.35) * 8)
                pygame.draw.polygon(self.canvas, (235, 235, 255), [(ex + 8, ey + 14), (ex - 8, wing_y), (ex + 18, ey + 14)])
                pygame.draw.polygon(self.canvas, (235, 235, 255), [(ex + 26, ey + 14), (ex + 52, wing_y), (ex + 36, ey + 14)])
                pygame.draw.ellipse(self.canvas, (150, 55, 210), (ex + 4, ey + 4, en.rect.w - 8, en.rect.h - 6))
                pygame.draw.circle(self.canvas, (255, 235, 60), (ex + 16, ey + 15), 4)
                pygame.draw.circle(self.canvas, (255, 235, 60), (ex + 28, ey + 15), 4)
            else:
                col = (195, 55, 55) if en.kind == "walker" else (240, 105, 25)
                pygame.draw.rect(self.canvas, col, (ex, ey + 4, en.rect.w, en.rect.h - 4), border_radius=10)
                # Ojos enojados
                pygame.draw.circle(self.canvas, (255, 255, 255), (ex + 12, ey + 16), 5)
                pygame.draw.circle(self.canvas, (255, 255, 255), (ex + 28, ey + 16), 5)
                pygame.draw.circle(self.canvas, (20, 20, 20), (ex + 12, ey + 16), 2)
                pygame.draw.circle(self.canvas, (20, 20, 20), (ex + 28, ey + 16), 2)

    def draw_hud(self, w_data: dict):
        # Barra superior semitransparente
        hud_bg = pygame.Surface((BASE_W, 64), pygame.SRCALPHA)
        hud_bg.fill((15, 20, 35, 185))
        self.canvas.blit(hud_bg, (0, 0))

        # Info Jugadores
        for idx, p in enumerate(self.players):
            bx = 22 + idx * 330
            status = f"J{p.player_num}: {p.char['name']}"
            txt = self.font_small.render(status, True, (255, 255, 255))
            self.canvas.blit(txt, (bx, 8))

            if p.alive:
                hearts_str = "♥ " * p.hp + "♡ " * (p.max_hp - p.hp)
                h_txt = self.font_med.render(f"{hearts_str} | Pts: {p.score}", True, (255, 110, 135))
            else:
                h_txt = self.font_small.render("CAÍDO (Recoge ♥ o llega a Meta)", True, (255, 200, 90))
            self.canvas.blit(h_txt, (bx, 32))

        # Mundo actual y controles rápidos
        w_txt = self.font_med.render(w_data["name"], True, (120, 240, 255))
        self.canvas.blit(w_txt, (BASE_W - w_txt.get_width() - 24, 10))
        hint = self.font_tiny.render("[F11] Pantalla Completa | [M] Música | [R] Reiniciar | [ESC] Menú", True, (200, 210, 230))
        self.canvas.blit(hint, (BASE_W - hint.get_width() - 24, 38))

    def update_playing(self):
        w_data = WORLDS[self.world_idx]
        keys = pygame.key.get_pressed()

        for plat in self.platforms:
            plat.update(self.tick)
        for en in self.enemies:
            en.update(self.tick)

        for p in self.players:
            if not p.alive:
                continue
            p.update(keys, self.platforms, w_data["length"], w_data["friction"], self.sound, self.particles)

            # Caída al vacío / lava / agua
            if p.rect.top > BASE_H - 10:
                p.hp = 0
                p.alive = False
                self.sound.play_sfx("hurt")
                for _ in range(18):
                    self.particles.append(Particle(p.rect.centerx, BASE_H - 25, (255, 120, 50)))
                continue

            # Pinchos
            for sp in self.spikes:
                if p.rect.colliderect(sp):
                    p.take_damage(1, self.sound, self.particles)

            # Enemigos (aplastar por arriba o recibir golpe)
            for en in self.enemies:
                if not en.alive:
                    continue
                if p.rect.colliderect(en.rect):
                    if p.vy > 0 and p.rect.bottom - en.rect.top < 24:
                        en.alive = False
                        p.vy = -11.5
                        p.score += 100
                        self.sound.play_sfx("stomp")
                        for _ in range(15):
                            self.particles.append(Particle(en.rect.centerx, en.rect.centery, (255, 220, 80)))
                    else:
                        p.take_damage(1, self.sound, self.particles)

            # Monedas
            for c in self.coins[:]:
                if p.rect.colliderect(c):
                    self.coins.remove(c)
                    p.score += 50
                    self.sound.play_sfx("coin")
                    for _ in range(8):
                        self.particles.append(Particle(c.centerx, c.centery, (255, 230, 70), life=20))

            # Corazones (curan o reviven al compañero caído)
            for h in self.hearts[:]:
                if p.rect.colliderect(h):
                    self.hearts.remove(h)
                    self.sound.play_sfx("revive")
                    revived_someone = False
                    for mate in self.players:
                        if not mate.alive:
                            mate.respawn_near(p.rect.x, p.rect.y)
                            revived_someone = True
                    if not revived_someone:
                        p.hp = min(p.max_hp, p.hp + 1)
                    for _ in range(16):
                        self.particles.append(Particle(h.centerx, h.centery, (255, 90, 150)))

            # Meta del nivel: basta con que UN jugador vivo llegue al portal
            if p.rect.colliderect(self.goal_rect):
                self.sound.play_sfx("win")
                if self.world_idx + 1 < len(WORLDS):
                    self.state = "LEVEL_CLEAR"
                else:
                    self.state = "VICTORY"
                return

        # Verificar si TODOS los jugadores murieron
        alive_players = [p for p in self.players if p.alive]
        if not alive_players:
            self.sound.stop_music()
            self.state = "GAME_OVER"
            return

        # Cámara dinámica que sigue a los jugadores vivos
        avg_x = sum(p.rect.centerx for p in alive_players) / len(alive_players)
        target_cam = max(0.0, min(float(w_data["length"] - BASE_W), avg_x - BASE_W * 0.42))
        self.cam_x += (target_cam - self.cam_x) * 0.12

        # Mantener al segundo jugador dentro de la pantalla si ambos están vivos
        if len(alive_players) == 2:
            for p in alive_players:
                if p.rect.left < self.cam_x + 12:
                    p.rect.left = int(self.cam_x + 12)
                elif p.rect.right > self.cam_x + BASE_W - 12:
                    p.rect.right = int(self.cam_x + BASE_W - 12)

        for pt in self.particles[:]:
            pt.update()
            if pt.life <= 0:
                self.particles.remove(pt)

    def draw_menu(self):
        self.draw_gradient_bg((20, 26, 56), (48, 72, 138))
        title = self.font_title.render("CHRONO JUMPERS: MULTIVERSO", True, (255, 225, 75))
        sub = self.font_med.render("Aventura Cooperativa de 5 Mundos | Edición Python", True, (185, 230, 255))
        self.canvas.blit(title, (BASE_W // 2 - title.get_width() // 2, 48))
        self.canvas.blit(sub, (BASE_W // 2 - sub.get_width() // 2, 114))

        # Selector de modo (1 o 2 jugadores)
        mode_text = f"MODO ACTUAL: {'2 JUGADORES (COOPERATIVO)' if self.num_players == 2 else '1 JUGADOR'}   [Pulsa 1 o 2 para cambiar]"
        m_surf = self.font_med.render(mode_text, True, (120, 255, 175))
        self.canvas.blit(m_surf, (BASE_W // 2 - m_surf.get_width() // 2, 175))

        # Tarjetas de selección de personaje
        cards_count = self.num_players
        card_w, card_h = 460, 270
        gap = 60
        total_w = cards_count * card_w + (cards_count - 1) * gap
        start_x = (BASE_W - total_w) // 2

        for idx in range(cards_count):
            cx = start_x + idx * (card_w + gap)
            cy = 235
            char = CHARACTERS[self.p1_char_idx if idx == 0 else self.p2_char_idx]

            pygame.draw.rect(self.canvas, (32, 42, 78), (cx, cy, card_w, card_h), border_radius=16)
            pygame.draw.rect(self.canvas, char["color"], (cx, cy, card_w, card_h), width=4, border_radius=16)

            p_lbl = self.font_large.render(f"JUGADOR {idx + 1}", True, (255, 255, 255))
            self.canvas.blit(p_lbl, (cx + 24, cy + 18))

            # Vista previa del personaje
            preview = Player(idx + 1, char, cx + 35, cy + 85)
            preview.draw(self.canvas, 0, self.font_tiny)

            c_name = self.font_med.render(f"<  {char['name']}  >", True, (255, 230, 100))
            c_desc = self.font_small.render(char["desc"], True, (220, 230, 245))
            c_stats = self.font_small.render(f"Vida: {'♥' * char['max_hp']}   Velocidad: {char['speed']}", True, (165, 245, 195))
            ctrl_hint = (
                "Cambiar: [A / D]  |  Jugar: [W A S D]"
                if idx == 0
                else "Cambiar: [◀ / ▶]  |  Jugar: [Flechas]"
            )
            c_ctrl = self.font_small.render(ctrl_hint, True, (180, 200, 240))

            self.canvas.blit(c_name, (cx + 110, cy + 78))
            self.canvas.blit(c_desc, (cx + 110, cy + 115))
            self.canvas.blit(c_stats, (cx + 110, cy + 148))
            self.canvas.blit(c_ctrl, (cx + 24, cy + 220))

        start_btn = self.font_large.render("PULSA [ENTER] O [ESPACIO] PARA COMENZAR", True, (255, 255, 255))
        self.canvas.blit(start_btn, (BASE_W // 2 - start_btn.get_width() // 2, 555))

        foot = self.font_small.render(
            "Si un jugador cae en modo 2P, el otro puede terminar el nivel o recoger un ♥ para revivirlo. [F11] Pantalla Completa",
            True,
            (195, 210, 235),
        )
        self.canvas.blit(foot, (BASE_W // 2 - foot.get_width() // 2, 625))

    def draw_overlay(self, title_str: str, subtitle_str: str, action_str: str, accent_col):
        overlay = pygame.Surface((BASE_W, BASE_H), pygame.SRCALPHA)
        overlay.fill((10, 12, 24, 195))
        self.canvas.blit(overlay, (0, 0))

        t1 = self.font_title.render(title_str, True, accent_col)
        t2 = self.font_large.render(subtitle_str, True, (240, 245, 255))
        t3 = self.font_med.render(action_str, True, (140, 250, 185))

        self.canvas.blit(t1, (BASE_W // 2 - t1.get_width() // 2, 220))
        self.canvas.blit(t2, (BASE_W // 2 - t2.get_width() // 2, 310))
        self.canvas.blit(t3, (BASE_W // 2 - t3.get_width() // 2, 410))

    def present(self):
        # Escala manteniendo la relación de aspecto en cualquier monitor
        win_w, win_h = self.screen.get_size()
        scale = min(win_w / BASE_W, win_h / BASE_H)
        new_w = int(BASE_W * scale)
        new_h = int(BASE_H * scale)
        scaled = pygame.transform.smoothscale(self.canvas, (new_w, new_h))
        self.screen.fill((0, 0, 0))
        self.screen.blit(scaled, ((win_w - new_w) // 2, (win_h - new_h) // 2))
        pygame.display.flip()

    def run(self):
        while True:
            self.tick += 1
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_F11:
                        self.toggle_fullscreen()
                    elif event.key == pygame.K_m:
                        self.sound.toggle_mute(self.world_idx)

                    if self.state == "MENU":
                        if event.key == pygame.K_1:
                            self.num_players = 1
                        elif event.key == pygame.K_2:
                            self.num_players = 2
                        elif event.key == pygame.K_a:
                            self.p1_char_idx = (self.p1_char_idx - 1) % len(CHARACTERS)
                        elif event.key == pygame.K_d:
                            self.p1_char_idx = (self.p1_char_idx + 1) % len(CHARACTERS)
                        elif event.key == pygame.K_LEFT:
                            self.p2_char_idx = (self.p2_char_idx - 1) % len(CHARACTERS)
                        elif event.key == pygame.K_RIGHT:
                            self.p2_char_idx = (self.p2_char_idx + 1) % len(CHARACTERS)
                        elif event.key in (pygame.K_RETURN, pygame.K_SPACE):
                            self.start_campaign()
                        elif event.key == pygame.K_ESCAPE:
                            pygame.quit()
                            sys.exit()

                    elif self.state == "PLAYING":
                        if event.key == pygame.K_r:
                            self.load_world(self.world_idx)
                        elif event.key == pygame.K_ESCAPE:
                            self.sound.stop_music()
                            self.state = "MENU"

                    elif self.state == "LEVEL_CLEAR":
                        if event.key in (pygame.K_RETURN, pygame.K_SPACE):
                            self.load_world(self.world_idx + 1)
                            self.state = "PLAYING"

                    elif self.state in ("GAME_OVER", "VICTORY"):
                        if event.key in (pygame.K_RETURN, pygame.K_SPACE):
                            self.start_campaign()
                        elif event.key == pygame.K_ESCAPE:
                            self.state = "MENU"

            if self.state == "MENU":
                self.draw_menu()
            else:
                w_data = WORLDS[self.world_idx]
                if self.state == "PLAYING":
                    self.update_playing()

                self.draw_world_scenery(w_data)
                self.draw_platforms_and_hazards(w_data)
                self.draw_collectibles_and_goal()
                self.draw_enemies()
                for p in self.players:
                    p.draw(self.canvas, self.cam_x, self.font_tiny)
                for pt in self.particles:
                    pt.draw(self.canvas, self.cam_x)
                self.draw_hud(w_data)

                if self.state == "LEVEL_CLEAR":
                    next_w = WORLDS[self.world_idx + 1]["name"]
                    self.draw_overlay(
                        "¡MUNDO COMPLETADO!",
                        f"Siguiente destino: {next_w}",
                        "Pulsa [ENTER] para continuar (¡Ambos jugadores reviven!)",
                        (100, 255, 165),
                    )
                elif self.state == "GAME_OVER":
                    self.draw_overlay(
                        "FIN DE LA PARTIDA",
                        "Ambos exploradores cayeron en batalla",
                        "Pulsa [ENTER] para reintentar o [ESC] para volver al menú",
                        (255, 95, 95),
                    )
                elif self.state == "VICTORY":
                    total_pts = sum(p.score for p in self.players)
                    self.draw_overlay(
                        "¡VICTORIA EN EL MULTIVERSO!",
                        f"Has conquistado los 5 mundos | Puntuación Total: {total_pts}",
                        "Pulsa [ENTER] para jugar de nuevo o [ESC] para el menú",
                        (255, 225, 75),
                    )

            self.present()
            self.clock.tick(FPS)


if __name__ == "__main__":
    game = ChronoJumpersGame()
    game.run()
