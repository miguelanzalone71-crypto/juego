import numpy as np
import pygame

SAMPLE_RATE = 44100


class SoundEngine:
    """Sintetizador procedural de música por bioma y efectos de sonido (SFX)."""

    def __init__(self):
        self.enabled = True
        self.muted = False
        self.music_channel = None
        self.tracks = {}
        self.sfx = {}
        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init(frequency=SAMPLE_RATE, size=-16, channels=2, buffer=512)
            self._build_sfx()
            self._build_world_tracks()
        except Exception as e:
            print(f"[Audio] No se pudo inicializar el audio: {e}")
            self.enabled = False

    def _make_sound(self, mono_wave: np.ndarray) -> pygame.mixer.Sound:
        mono_wave = np.clip(mono_wave, -1.0, 1.0)
        int_wave = (mono_wave * 32767).astype(np.int16)
        stereo = np.column_stack((int_wave, int_wave))
        return pygame.sndarray.make_sound(stereo)

    def _synth_note(self, freq: float, duration: float, wave_type="square", volume=0.2):
        t = np.linspace(0, duration, int(SAMPLE_RATE * duration), endpoint=False)
        if freq <= 0:
            return np.zeros_like(t)

        if wave_type == "square":
            wave = np.sign(np.sin(2 * np.pi * freq * t))
        elif wave_type == "triangle":
            wave = 2 * np.abs(2 * (t * freq - np.floor(t * freq + 0.5))) - 1
        elif wave_type == "saw":
            wave = 2 * (t * freq - np.floor(t * freq + 0.5))
        else:
            wave = np.sin(2 * np.pi * freq * t)

        # Envolvente ADSR rápida para evitar clics
        attack = min(int(0.01 * SAMPLE_RATE), len(t) // 4)
        release = min(int(0.04 * SAMPLE_RATE), len(t) // 3)
        env = np.ones_like(t)
        if attack > 0:
            env[:attack] = np.linspace(0, 1, attack)
        if release > 0:
            env[-release:] = np.linspace(1, 0, release)

        return wave * env * volume

    def _build_sfx(self):
        # Salto
        dur = 0.14
        t = np.linspace(0, dur, int(SAMPLE_RATE * dur), endpoint=False)
        freqs = np.linspace(260, 620, len(t))
        jump_wave = np.sign(np.sin(2 * np.pi * np.cumsum(freqs) / SAMPLE_RATE)) * np.linspace(0.22, 0.02, len(t))
        self.sfx["jump"] = self._make_sound(jump_wave)

        # Moneda / Cristal
        c1 = self._synth_note(987.77, 0.06, "sine", 0.25)
        c2 = self._synth_note(1318.51, 0.14, "sine", 0.25)
        self.sfx["coin"] = self._make_sound(np.concatenate([c1, c2]))

        # Aplastar enemigo
        dur_s = 0.12
        t_s = np.linspace(0, dur_s, int(SAMPLE_RATE * dur_s), endpoint=False)
        f_s = np.linspace(380, 90, len(t_s))
        stomp = (2 * (t_s * f_s - np.floor(t_s * f_s + 0.5)) - 1) * np.linspace(0.3, 0.01, len(t_s))
        self.sfx["stomp"] = self._make_sound(stomp)

        # Daño / Caída
        h1 = self._synth_note(220, 0.09, "saw", 0.28)
        h2 = self._synth_note(146.83, 0.18, "saw", 0.28)
        self.sfx["hurt"] = self._make_sound(np.concatenate([h1, h2]))

        # Revivir / Vida extra
        r_notes = [523.25, 659.25, 783.99, 1046.50]
        self.sfx["revive"] = self._make_sound(np.concatenate([self._synth_note(n, 0.08, "triangle", 0.26) for n in r_notes]))

        # Meta / Portal
        w_notes = [523.25, 659.25, 783.99, 1046.50, 783.99, 1046.50]
        w_durs = [0.1, 0.1, 0.1, 0.18, 0.1, 0.35]
        self.sfx["win"] = self._make_sound(
            np.concatenate([self._synth_note(n, d, "square", 0.2) for n, d in zip(w_notes, w_durs)])
        )

    def _build_world_tracks(self):
        # 5 melodías distintas (en Hz) para los 5 mundos
        world_melodies = [
            # Mundo 1: Pradera Esmeralda (Alegre en Do Mayor)
            (0.20, "square", [523.25, 659.25, 783.99, 659.25, 880.00, 783.99, 659.25, 587.33,
                              523.25, 587.33, 659.25, 783.99, 659.25, 523.25, 587.33, 0]),
            # Mundo 2: Desierto Dorado (Escala Hijaz / Exótica)
            (0.22, "triangle", [440.00, 466.16, 554.37, 587.33, 659.25, 587.33, 554.37, 466.16,
                                440.00, 554.37, 659.25, 698.46, 659.25, 554.37, 466.16, 440.00]),
            # Mundo 3: Caverna de Cristal (Misteriosa y brillante)
            (0.24, "sine", [659.25, 783.99, 987.77, 1174.66, 987.77, 783.99, 659.25, 587.33,
                            493.88, 587.33, 739.99, 987.77, 739.99, 587.33, 493.88, 0]),
            # Mundo 4: Cumbre Helada (Invernal y rápida)
            (0.18, "triangle", [587.33, 698.46, 880.00, 1046.50, 880.00, 698.46, 659.25, 523.25,
                                587.33, 880.00, 783.99, 698.46, 659.25, 587.33, 523.25, 587.33]),
            # Mundo 5: Fortaleza Volcánica (Intensa y oscura)
            (0.16, "saw", [220.00, 220.00, 261.63, 246.94, 220.00, 329.63, 311.13, 293.66,
                           220.00, 220.00, 349.23, 329.63, 293.66, 261.63, 246.94, 196.00]),
        ]

        for idx, (step_dur, w_type, notes) in enumerate(world_melodies):
            lead = np.concatenate([self._synth_note(n, step_dur, w_type, 0.11) for n in notes])
            bass_notes = [n / 2 if n > 0 else 0 for n in notes]
            bass = np.concatenate([self._synth_note(n, step_dur, "triangle", 0.12) for n in bass_notes])
            min_len = min(len(lead), len(bass))
            self.tracks[idx] = self._make_sound(lead[:min_len] + bass[:min_len])

    def play_sfx(self, name: str):
        if self.enabled and not self.muted and name in self.sfx:
            self.sfx[name].play()

    def play_music(self, world_index: int):
        if not self.enabled:
            return
        self.stop_music()
        if not self.muted and world_index in self.tracks:
            self.music_channel = self.tracks[world_index].play(loops=-1)

    def stop_music(self):
        if self.music_channel is not None:
            self.music_channel.stop()
            self.music_channel = None

    def toggle_mute(self, current_world: int):
        self.muted = not self.muted
        if self.muted:
            self.stop_music()
        else:
            self.play_music(current_world)
