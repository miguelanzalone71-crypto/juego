# CHRONO JUMPERS: MULTIVERSO (Edición Python / Pygame)

Videojuego de plataformas y aventura cooperativa para 1 o 2 jugadores con 5 mundos distintos, música sintetizada proceduralmente, 4 personajes con habilidades únicas y modo pantalla completa.

## Requisitos e Instalación en Visual Studio Code (VS Code)

1. Descomprime esta carpeta y ábrela en **Visual Studio Code** (`Archivo > Abrir carpeta...`).
2. Abre la terminal integrada en VS Code (`Ctrl + Ñ` o `Terminal > Nueva terminal`).
3. Instala las dependencias necesarias ejecutando:
   ```bash
   pip install -r requirements.txt
   ```
4. Ejecuta el juego:
   ```bash
   python main.py
   ```

## Controles

- **Menú / Selección:**
  - `1` / `2`: Cambiar entre 1 Jugador o 2 Jugadores Cooperativo.
  - `A` / `D`: Cambiar personaje del Jugador 1.
  - `Izquierda` / `Derecha`: Cambiar personaje del Jugador 2.
  - `ENTER` o `ESPACIO`: Iniciar partida / Siguiente nivel.
- **En Juego:**
  - **Jugador 1:** `W` (Saltar), `A` / `D` (Moverse).
  - **Jugador 2:** `Flecha Arriba` (Saltar), `Flecha Izquierda` / `Flecha Derecha` (Moverse).
  - **General:** `F11` (Alternar Pantalla Completa / Ventana), `M` (Silenciar/Activar música), `R` (Reiniciar nivel), `ESC` (Volver al menú).

## Mecánica Cooperativa

- Si un jugador cae al vacío o pierde sus corazones, queda en modo **Fantasma/Espera** mientras su compañero sigue avanzando.
- Si el jugador vivo recoge un **Corazón Flotante (💖)** o completa el nivel llegando al **Portal Dimensional**, ¡su compañero revive automáticamente!
