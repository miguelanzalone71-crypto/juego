import pygame
import pygame.gfxdraw
import random
import math
import struct
import array
import json
import os
from sound_generator import ensure_music_assets

pygame.init()
pygame.mixer.pre_init(44100, -16, 1, 512)
pygame.mixer.init()

ensure_music_assets()

SAVE_FILE = "save_progress.json"

def load_save():
    if os.path.exists(SAVE_FILE):
        try:
            with open(SAVE_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                return {
                    "unlocked_stage": max(1, min(5, int(data.get("unlocked_stage", 1)))),
                    "current_stage": max(1, min(5, int(data.get("current_stage", 1)))),
                    "best_score": int(data.get("best_score", 0))
                }
        except Exception:
            pass
    return {"unlocked_stage": 1, "current_stage": 1, "best_score": 0}

def write_save(data):
    try:
        with open(SAVE_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
    except Exception:
        pass

def make_sfx(freq_start, freq_end, duration, wave_type="sine", volume=0.35):
    sample_rate = 44100
    n_samples = int(sample_rate * duration)
    buf = array.array('h')
    for i in range(n_samples):
        t = i / sample_rate
        progress = i / n_samples
        freq = freq_start + (freq_end - freq_start) * progress
        env = (1.0 - progress) * volume
        if wave_type == "sine":
            val = math.sin(2 * math.pi * freq * t)
        elif wave_type == "square":
            val = 1.0 if math.sin(2 * math.pi * freq * t) > 0 else -1.0
        else:
            val = random.uniform(-1.0, 1.0)
        buf.append(int(max(-32767, min(32767, val * env * 32767))))
    return pygame.mixer.Sound(buffer=buf)

SFX_CLICK = make_sfx(520, 880, 0.09, "sine", 0.3)
SFX_POWERUP = make_sfx(440, 1180, 0.22, "sine", 0.35)
SFX_CRASH = make_sfx(160, 35, 0.45, "noise", 0.5)
SFX_SHIELD = make_sfx(700, 300, 0.28, "square", 0.3)
SFX_JUMP = make_sfx(280, 760, 0.28, "sine", 0.35)
SFX_EMP = make_sfx(950, 140, 0.45, "square", 0.4)
SFX_TIME = make_sfx(600, 220, 0.35, "sine", 0.35)
SFX_VICTORY = make_sfx(440, 1320, 0.75, "sine", 0.45)

VIRTUAL_W, VIRTUAL_H = 1920, 1080
is_fullscreen = True

def create_display(fullscreen):
    if fullscreen:
        return pygame.display.set_mode((0, 0), pygame.FULLSCREEN | pygame.DOUBLEBUF)
    else:
        return pygame.display.set_mode((1280, 720), pygame.RESIZABLE | pygame.DOUBLEBUF)

display_screen = create_display(is_fullscreen)
pygame.display.set_caption("NEON STREET RACER: 5 STAGES WORLD TOUR HD")
clock = pygame.time.Clock()
virtual_screen = pygame.Surface((VIRTUAL_W, VIRTUAL_H)).convert()

# Colores base
NEON_CYAN = (0, 245, 255)
NEON_PINK = (255, 20, 147)
NEON_PURPLE = (180, 30, 255)
NEON_YELLOW = (255, 230, 0)
NEON_GREEN = (57, 255, 20)
NEON_ORANGE = (255, 120, 0)
NEON_RED = (255, 45, 75)
WHITE = (248, 250, 255)

# Configuración única de cada una de las 5 Fases (Fondo, Color de pista, Edificios y Obstáculos exclusivos)
STAGES_CONFIG = {
    1: {
        "name": "FASE 1: DISTRITO CYBER NEÓN",
        "subtitle": "Autopista Nocturna • Barreras y Manchas de Aceite",
        "bg_color": (10, 8, 24),
        "asphalt": (20, 18, 36),
        "edge_main": NEON_PINK,
        "edge_sub": NEON_CYAN,
        "building_tint": (18, 16, 40),
        "building_neons": [NEON_CYAN, NEON_PINK],
        "goal_dist": 15000.0,
        "base_speed": 16.0,
        "obstacles": ["barrier", "oil"],
        "scenery": "city",
        "default_music": 0
    },
    2: {
        "name": "FASE 2: PUERTO INDUSTRIAL TÓXICO",
        "subtitle": "Refinería Ácida • Puertas Láser y Barreras",
        "bg_color": (8, 22, 16),
        "asphalt": (16, 28, 24),
        "edge_main": NEON_GREEN,
        "edge_sub": NEON_YELLOW,
        "building_tint": (14, 34, 24),
        "building_neons": [NEON_GREEN, NEON_YELLOW],
        "goal_dist": 20000.0,
        "base_speed": 18.0,
        "obstacles": ["barrier", "laser_gate", "oil"],
        "scenery": "industrial",
        "default_music": 3
    },
    3: {
        "name": "FASE 3: CAÑÓN SOLAR DESÉRTICO",
        "subtitle": "Ruta del Crepúsculo • Drones Patrulla y Tornados de Arena",
        "bg_color": (28, 12, 8),
        "asphalt": (34, 20, 16),
        "edge_main": NEON_ORANGE,
        "edge_sub": NEON_YELLOW,
        "building_tint": (44, 22, 14),
        "building_neons": [NEON_ORANGE, NEON_RED],
        "goal_dist": 25000.0,
        "base_speed": 20.0,
        "obstacles": ["drone", "barrier", "sand_whirl"],
        "scenery": "canyon",
        "default_music": 1
    },
    4: {
        "name": "FASE 4: AUTOPISTA ÁRTICA CRIOGÉNICA",
        "subtitle": "Glaciar Boreal • Placas de Hielo, Láseres y Drones",
        "bg_color": (6, 18, 34),
        "asphalt": (16, 30, 48),
        "edge_main": (120, 230, 255),
        "edge_sub": WHITE,
        "building_tint": (18, 38, 62),
        "building_neons": [(120, 230, 255), NEON_PURPLE],
        "goal_dist": 30000.0,
        "base_speed": 22.0,
        "obstacles": ["ice_patch", "laser_gate", "drone"],
        "scenery": "arctic",
        "default_music": 4
    },
    5: {
        "name": "FASE 5: NÚCLEO OMEGA (FINAL)",
        "subtitle": "Fortaleza Orbital • Todos los Obstáculos y Láseres Dobles",
        "bg_color": (22, 4, 28),
        "asphalt": (28, 10, 34),
        "edge_main": NEON_RED,
        "edge_sub": NEON_PURPLE,
        "building_tint": (36, 10, 44),
        "building_neons": [NEON_RED, NEON_PURPLE, NEON_YELLOW],
        "goal_dist": 36000.0,
        "base_speed": 24.0,
        "obstacles": ["laser_gate", "drone", "barrier", "sand_whirl", "ice_patch"],
        "scenery": "omega",
        "default_music": 2
    }
}

font_title = pygame.font.SysFont("Consolas", 68, bold=True)
font_subtitle = pygame.font.SysFont("Consolas", 28, bold=True)
font_btn = pygame.font.SysFont("Consolas", 28, bold=True)
font_ui = pygame.font.SysFont("Consolas", 24, bold=True)
font_small = pygame.font.SysFont("Consolas", 18, bold=True)

MUSIC_TRACKS = [
    {"name": "1. SYNTHWAVE NIGHTS", "file": "assets/music/synthwave.wav", "color": NEON_CYAN},
    {"name": "2. DRIFT PHONK 808", "file": "assets/music/phonk.wav", "color": NEON_PINK},
    {"name": "3. EUROBEAT TURBO", "file": "assets/music/eurobeat.wav", "color": NEON_YELLOW},
    {"name": "4. CYBER ROCK", "file": "assets/music/rock.wav", "color": NEON_ORANGE},
    {"name": "5. DARK ELECTRO", "file": "assets/music/electro.wav", "color": NEON_PURPLE},
    {"name": "6. MIDNIGHT JAZZ", "file": "assets/music/jazz.wav", "color": NEON_GREEN},
    {"name": "7. CHILL LO-FI", "file": "assets/music/lofi.wav", "color": (120, 220, 255)},
    {"name": "8. SPACE AMBIENT", "file": "assets/music/ambient.wav", "color": (220, 150, 255)},
]
current_track_idx = 0
sound_enabled = True

def play_sfx(sfx):
    if sound_enabled:
        sfx.play()

def play_current_music():
    if sound_enabled:
        track = MUSIC_TRACKS[current_track_idx]
        pygame.mixer.music.load(track["file"])
        pygame.mixer.music.set_volume(0.55)
        pygame.mixer.music.play(-1)

def toggle_sound():
    global sound_enabled
    sound_enabled = not sound_enabled
    if sound_enabled:
        play_current_music()
        SFX_CLICK.play()
    else:
        pygame.mixer.music.stop()

def next_music_track(step=1):
    global current_track_idx
    current_track_idx = (current_track_idx + step) % len(MUSIC_TRACKS)
    if sound_enabled:
        play_current_music()
        SFX_CLICK.play()

class UIButton:
    def __init__(self, rect, text, color, icon=""):
        self.rect = pygame.Rect(rect)
        self.text = text
        self.color = color
        self.icon = icon

    def is_hovered(self, mouse_pos):
        return self.rect.collidepoint(mouse_pos)

    def draw(self, surf, mouse_pos):
        hovered = self.is_hovered(mouse_pos)
        bg = (38, 34, 68) if hovered else (18, 16, 36)
        border_w = 4 if hovered else 3

        if hovered:
            glow_rect = self.rect.inflate(10, 10)
            glow_surf = pygame.Surface(glow_rect.size, pygame.SRCALPHA)
            pygame.draw.rect(glow_surf, (*self.color, 55), glow_surf.get_rect(), border_radius=16)
            surf.blit(glow_surf, glow_rect.topleft)

        pygame.draw.rect(surf, bg, self.rect, border_radius=14)
        pygame.draw.rect(surf, self.color, self.rect, border_w, border_radius=14)

        label = f"{self.icon} {self.text}".strip()
        txt_surf = font_btn.render(label, True, WHITE if hovered else self.color)
        surf.blit(txt_surf, (
            self.rect.centerx - txt_surf.get_width() // 2,
            self.rect.centery - txt_surf.get_height() // 2
        ))

ROAD_LEFT = 460
ROAD_RIGHT = VIRTUAL_W - 460
ROAD_WIDTH = ROAD_RIGHT - ROAD_LEFT
LANES = [560, 760, 960, 1160, 1360]

def draw_aa_circle(surf, color, x, y, r):
    pygame.gfxdraw.aacircle(surf, int(x), int(y), int(r), color)
    pygame.gfxdraw.filled_circle(surf, int(x), int(y), int(r), color)

class Particle:
    def __init__(self, x, y, vx, vy, color, size, life):
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.color = color
        self.size = size
        self.life = life
        self.max_life = life

    def update(self):
        self.x += self.vx
        self.y += self.vy
        self.life -= 1
        self.size = max(0, self.size * (self.life / self.max_life))

    def draw(self, surf):
        if self.life > 0 and self.size >= 1:
            draw_aa_circle(surf, self.color, self.x, self.y, self.size)

class EMPWave:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.radius = 40
        self.max_radius = 680
        self.active = True

    def update(self):
        self.radius += 28
        if self.radius >= self.max_radius:
            self.active = False

    def draw(self, surf):
        if self.active:
            alpha = max(0, int(255 * (1 - self.radius / self.max_radius)))
            s = pygame.Surface((self.radius * 2 + 20, self.radius * 2 + 20), pygame.SRCALPHA)
            pygame.draw.circle(s, (0, 245, 255, alpha), (self.radius + 10, self.radius + 10), self.radius, 8)
            surf.blit(s, (self.x - self.radius - 10, self.y - self.radius - 10))

class SkidMark:
    def __init__(self, x, y, alpha=170):
        self.x = x
        self.y = y
        self.alpha = alpha

    def update(self, speed):
        self.y += speed
        self.alpha -= 2.5

    def draw(self, surf):
        if self.alpha > 0:
            s = pygame.Surface((12, 22), pygame.SRCALPHA)
            s.fill((8, 8, 12, max(0, int(self.alpha))))
            surf.blit(s, (self.x - 6, self.y - 11))

class SceneryObject:
    def __init__(self, side):
        self.side = side
        self.reset(random.randint(-VIRTUAL_H, VIRTUAL_H))

    def reset(self, y_pos):
        self.w = random.randint(150, 260)
        self.h = random.randint(200, 400)
        if self.side == "left":
            self.x = random.randint(20, ROAD_LEFT - self.w - 30)
        else:
            self.x = random.randint(ROAD_RIGHT + 30, VIRTUAL_W - self.w - 20)
        self.y = y_pos
        self.neon_idx = random.randint(0, 5)

    def update(self, speed):
        self.y += speed * 0.85
        if self.y > VIRTUAL_H:
            self.reset(-self.h - random.randint(30, 140))

    def draw(self, surf, cfg):
        base_col = cfg["building_tint"]
        neons = cfg["building_neons"]
        neon = neons[self.neon_idx % len(neons)]
        scenery_type = cfg["scenery"]

        if scenery_type == "canyon":
            # Formaciones rocosas del cañón solar
            pts = [
                (self.x + self.w // 2, self.y),
                (self.x + self.w, self.y + self.h * 0.35),
                (self.x + self.w * 0.85, self.y + self.h),
                (self.x + self.w * 0.15, self.y + self.h),
                (self.x, self.y + self.h * 0.35)
            ]
            pygame.draw.polygon(surf, base_col, pts)
            pygame.draw.polygon(surf, neon, pts, 3)
        elif scenery_type == "arctic":
            # Cristales de hielo y glaciares
            pts = [
                (self.x + self.w // 2, self.y),
                (self.x + self.w, self.y + self.h),
                (self.x, self.y + self.h)
            ]
            pygame.draw.polygon(surf, base_col, pts)
            pygame.draw.polygon(surf, neon, pts, 3)
        else:
            # Edificios / Torres industriales / Reactores Omega
            pygame.draw.rect(surf, base_col, (self.x, self.y, self.w, self.h), border_radius=8)
            pygame.draw.rect(surf, neon, (self.x, self.y, self.w, self.h), 3, border_radius=8)
            for wy in range(int(self.y) + 24, int(self.y + self.h) - 24, 36):
                for wx in range(int(self.x) + 24, int(self.x + self.w) - 24, 32):
                    if (wx + wy) % 3 == 0:
                        pygame.draw.rect(surf, neon, (wx, wy, 12, 18), border_radius=2)

# Obstáculos Variados según cada Fase
class Obstacle:
    def __init__(self, allowed_types, stage_num=1):
        self.kind = random.choice(allowed_types)
        self.y = -140.0
        self.timer = random.uniform(0, math.pi * 2)

        if self.kind == "barrier":
            self.lane = random.choice(LANES)
            self.x = float(self.lane)
            self.w, self.h = 140, 42
        elif self.kind == "laser_gate":
            idx = random.randint(0, len(LANES) - 2)
            self.x = (LANES[idx] + LANES[idx + 1]) / 2.0
            self.w, self.h = 340, 26
        elif self.kind in ["oil", "ice_patch"]:
            self.lane = random.choice(LANES)
            self.x = float(self.lane)
            self.w, self.h = 125, 105
        elif self.kind == "sand_whirl":
            self.x = float(random.choice(LANES))
            self.w, self.h = 110, 110
            self.vx = random.choice([-3.5, 3.5])
        else:  # drone
            self.x = float(random.choice(LANES))
            self.w, self.h = 74, 74
            self.vx = random.choice([-4.8, 4.8]) * (1 + stage_num * 0.12)

    def update(self, road_speed):
        self.y += road_speed
        self.timer += 0.08
        if self.kind in ["drone", "sand_whirl"]:
            self.x += self.vx
            if self.x < ROAD_LEFT + 65 or self.x > ROAD_RIGHT - 65:
                self.vx *= -1

    def is_lethal(self):
        if self.kind == "laser_gate":
            return math.sin(self.timer * 0.85) > -0.25
        if self.kind in ["oil", "ice_patch", "sand_whirl"]:
            return False  # Alteran la física o empujan el coche
        return True

    def get_rect(self):
        return pygame.Rect(self.x - self.w // 2, self.y - self.h // 2, self.w, self.h)

    def draw(self, surf):
        rect = self.get_rect()
        if self.kind == "barrier":
            pygame.draw.rect(surf, (45, 20, 25), rect, border_radius=8)
            pygame.draw.rect(surf, NEON_RED, rect, 3, border_radius=8)
            for sx in range(rect.left + 12, rect.right - 12, 24):
                pygame.draw.line(surf, NEON_YELLOW, (sx, rect.top + 6), (sx + 12, rect.bottom - 6), 4)

        elif self.kind == "laser_gate":
            pygame.draw.rect(surf, (30, 30, 50), (rect.left - 12, rect.top - 8, 24, self.h + 16), border_radius=6)
            pygame.draw.rect(surf, (30, 30, 50), (rect.right - 12, rect.top - 8, 24, self.h + 16), border_radius=6)
            if self.is_lethal():
                pygame.draw.line(surf, NEON_RED, (rect.left, rect.centery), (rect.right, rect.centery), 10)
                pygame.draw.line(surf, WHITE, (rect.left, rect.centery), (rect.right, rect.centery), 3)
            else:
                pygame.draw.line(surf, (90, 40, 50), (rect.left, rect.centery), (rect.right, rect.centery), 2)

        elif self.kind == "oil":
            pygame.draw.ellipse(surf, (12, 10, 20), rect)
            pygame.draw.ellipse(surf, NEON_PURPLE, rect, 3)

        elif self.kind == "ice_patch":
            pygame.draw.ellipse(surf, (140, 235, 255), rect)
            pygame.draw.ellipse(surf, WHITE, rect, 3)

        elif self.kind == "sand_whirl":
            for r in [50, 34, 18]:
                ang = self.timer * 5 + r
                ox = math.cos(ang) * 6
                oy = math.sin(ang) * 6
                pygame.draw.circle(surf, NEON_ORANGE, (int(self.x + ox), int(self.y + oy)), r, 3)

        else:  # drone
            pygame.draw.circle(surf, (35, 18, 48), (int(self.x), int(self.y)), 34)
            pygame.draw.circle(surf, NEON_ORANGE, (int(self.x), int(self.y)), 34, 4)
            ang = self.timer * 4
            for k in range(4):
                a = ang + k * (math.pi / 2)
                px = self.x + math.cos(a) * 42
                py = self.y + math.sin(a) * 42
                pygame.draw.line(surf, NEON_CYAN, (self.x, self.y), (px, py), 3)

# Arco de Salida (Inicio de cada fase) y Línea de Meta (Final de cada fase)
class RoadBanner:
    def __init__(self, y_start, title_text, color):
        self.y = float(y_start)
        self.title_text = title_text
        self.color = color
        self.crossed = False

    def update(self, road_speed):
        self.y += road_speed

    def draw(self, surf):
        banner_rect = pygame.Rect(ROAD_LEFT - 20, self.y - 40, ROAD_WIDTH + 40, 80)
        sq = 32
        for row in range(2):
            for col in range(int(ROAD_WIDTH // sq) + 1):
                c = WHITE if (row + col) % 2 == 0 else (20, 20, 35)
                pygame.draw.rect(surf, c, (ROAD_LEFT + col * sq, self.y - 32 + row * sq, sq, sq))

        pygame.draw.rect(surf, self.color, banner_rect, 5)
        lbl = font_subtitle.render(self.title_text, True, self.color)
        bg_lbl = pygame.Rect(VIRTUAL_W // 2 - lbl.get_width() // 2 - 22, self.y - 90, lbl.get_width() + 44, 44)
        pygame.draw.rect(surf, (12, 14, 28), bg_lbl, border_radius=10)
        pygame.draw.rect(surf, self.color, bg_lbl, 3, border_radius=10)
        surf.blit(lbl, (VIRTUAL_W // 2 - lbl.get_width() // 2, self.y - 83))

class PlayerCar:
    def __init__(self):
        self.x = VIRTUAL_W // 2
        self.y = VIRTUAL_H - 200
        self.vx = 0.0
        self.vy = 0.0
        self.angle = 0.0
        self.nitro = 100.0
        self.energy = 100.0
        self.is_boosting = False
        self.is_drifting = False
        self.invulnerable = 0
        self.shield = False
        self.slip_timer = 0

        self.jump_timer = 0
        self.jump_cd = 0
        self.emp_cd = 0
        self.slow_timer = 0
        self.slow_cd = 0

        self.base_sprite = self._build_hd_sprite()

    def _build_hd_sprite(self):
        scale = 2
        w, h = 110 * scale, 180 * scale
        s = pygame.Surface((w, h), pygame.SRCALPHA)
        cx, cy = w // 2, h // 2

        for wx in [-36, 26]:
            for wy in [-48, 32]:
                pygame.draw.rect(s, (12, 12, 18), (cx + wx * scale, cy + wy * scale, 10 * scale, 26 * scale), border_radius=4 * scale)

        body_pts = [
            (cx - 28 * scale, cy - 68 * scale), (cx + 28 * scale, cy - 68 * scale),
            (cx + 35 * scale, cy - 15 * scale), (cx + 32 * scale, cy + 68 * scale),
            (cx - 32 * scale, cy + 68 * scale), (cx - 35 * scale, cy - 15 * scale)
        ]
        pygame.draw.polygon(s, (22, 24, 44), body_pts)
        pygame.draw.polygon(s, NEON_CYAN, body_pts, 3 * scale)

        pygame.draw.line(s, NEON_PINK, (cx - 10 * scale, cy - 64 * scale), (cx - 10 * scale, cy - 28 * scale), 3 * scale)
        pygame.draw.line(s, NEON_PINK, (cx + 10 * scale, cy - 64 * scale), (cx + 10 * scale, cy - 28 * scale), 3 * scale)

        cabin_pts = [
            (cx - 22 * scale, cy - 28 * scale), (cx + 22 * scale, cy - 28 * scale),
            (cx + 19 * scale, cy + 22 * scale), (cx - 19 * scale, cy + 22 * scale)
        ]
        pygame.draw.polygon(s, (8, 12, 26), cabin_pts)
        pygame.draw.polygon(s, NEON_CYAN, cabin_pts, 2 * scale)

        pygame.draw.rect(s, NEON_PINK, (cx - 36 * scale, cy + 58 * scale, 72 * scale, 10 * scale), border_radius=3 * scale)
        pygame.draw.rect(s, WHITE, (cx - 24 * scale, cy - 70 * scale, 12 * scale, 6 * scale), border_radius=2 * scale)
        pygame.draw.rect(s, WHITE, (cx + 12 * scale, cy - 70 * scale, 12 * scale, 6 * scale), border_radius=2 * scale)

        return pygame.transform.smoothscale(s, (110, 180))

    def trigger_jump(self, particles):
        if self.jump_cd == 0 and self.energy >= 25:
            self.energy -= 25
            self.jump_timer = 48
            self.jump_cd = 120
            play_sfx(SFX_JUMP)
            for _ in range(25):
                particles.append(Particle(self.x, self.y + 40, random.uniform(-6, 6), random.uniform(-2, 8), NEON_YELLOW, 8, 22))

    def trigger_emp(self, emp_waves, obstacles, traffic, particles):
        if self.emp_cd == 0 and self.energy >= 45:
            self.energy -= 45
            self.emp_cd = 240
            play_sfx(SFX_EMP)
            emp_waves.append(EMPWave(self.x, self.y))
            for obs in obstacles[:]:
                if math.hypot(obs.x - self.x, obs.y - self.y) < 650:
                    for _ in range(18):
                        particles.append(Particle(obs.x, obs.y, random.uniform(-8, 8), random.uniform(-8, 8), NEON_CYAN, 7, 25))
                    obstacles.remove(obs)
            for car in traffic[:]:
                if math.hypot(car.x - self.x, car.y - self.y) < 650:
                    for _ in range(22):
                        particles.append(Particle(car.x, car.y, random.uniform(-8, 8), random.uniform(-8, 8), NEON_PINK, 8, 25))
                    traffic.remove(car)

    def trigger_slow_time(self):
        if self.slow_cd == 0 and self.energy >= 35:
            self.energy -= 35
            self.slow_timer = 180
            self.slow_cd = 300
            play_sfx(SFX_TIME)

    def update(self, keys, particles, skids):
        self.energy = min(100.0, self.energy + 0.14)
        if self.jump_cd > 0:
            self.jump_cd -= 1
        if self.emp_cd > 0:
            self.emp_cd -= 1
        if self.slow_cd > 0:
            self.slow_cd -= 1
        if self.jump_timer > 0:
            self.jump_timer -= 1
        if self.slow_timer > 0:
            self.slow_timer -= 1
        if self.slip_timer > 0:
            self.slip_timer -= 1

        accel = 1.35
        friction = 0.88 if self.slip_timer == 0 else 0.98
        max_vx = 18.0 if not self.is_drifting else 24.0

        move_x = 0
        move_y = 0
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            move_x -= 1
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            move_x += 1
        if keys[pygame.K_UP] or keys[pygame.K_w]:
            move_y -= 1
        if keys[pygame.K_DOWN] or keys[pygame.K_s]:
            move_y += 1

        if self.slip_timer > 0:
            move_x += math.sin(self.slip_timer * 0.45) * 1.6

        self.is_drifting = (keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT]) and move_x != 0 and self.jump_timer == 0

        if keys[pygame.K_SPACE] and self.nitro > 2:
            self.is_boosting = True
            self.nitro = max(0, self.nitro - 0.65)
        else:
            self.is_boosting = False
            self.nitro = min(100, self.nitro + 0.2)

        self.vx = (self.vx + move_x * accel) * friction
        self.vy = (self.vy + move_y * (accel * 0.85)) * friction
        self.vx = max(-max_vx, min(max_vx, self.vx))

        self.x += self.vx
        self.y += self.vy

        if self.x < ROAD_LEFT + 45:
            self.x = ROAD_LEFT + 45
            self.vx *= -0.45
        elif self.x > ROAD_RIGHT - 45:
            self.x = ROAD_RIGHT - 45
            self.vx *= -0.45

        self.y = max(160, min(VIRTUAL_H - 110, self.y))

        target_angle = -self.vx * (1.8 if self.is_drifting else 1.2)
        self.angle += (target_angle - self.angle) * 0.22

        if self.is_drifting:
            skids.append(SkidMark(self.x - 26, self.y + 48))
            skids.append(SkidMark(self.x + 26, self.y + 48))
            if random.random() < 0.7:
                particles.append(Particle(self.x + random.choice([-28, 28]), self.y + 52,
                                          random.uniform(-3, 3), random.uniform(3, 8), NEON_YELLOW, 6, 18))

        flame_color = NEON_CYAN if self.is_boosting else NEON_PINK
        flame_count = 4 if self.is_boosting else 2
        for _ in range(flame_count):
            particles.append(Particle(
                self.x + random.uniform(-14, 14),
                self.y + 72,
                random.uniform(-1.2, 1.2),
                random.uniform(6, 14 if self.is_boosting else 9),
                flame_color,
                random.randint(6, 11 if self.is_boosting else 7),
                random.randint(12, 22)
            ))

        if self.invulnerable > 0:
            self.invulnerable -= 1

    def draw(self, surf):
        if self.invulnerable > 0 and (self.invulnerable // 4) % 2 == 0:
            return

        jump_height = math.sin((self.jump_timer / 48.0) * math.pi) if self.jump_timer > 0 else 0.0
        scale = 1.0 + jump_height * 0.42

        if jump_height > 0:
            shadow = pygame.Surface((110, 170), pygame.SRCALPHA)
            pygame.draw.ellipse(shadow, (0, 0, 0, 120), (10, 10, 90, 150))
            surf.blit(shadow, (self.x - 55 + jump_height * 35, self.y - 85 + jump_height * 45))

        beam = pygame.Surface((140, 220), pygame.SRCALPHA)
        pygame.draw.polygon(beam, (220, 245, 255, 32), [(45, 220), (95, 220), (135, 0), (5, 0)])
        rot_beam = pygame.transform.rotozoom(beam, self.angle, scale)
        b_rect = rot_beam.get_rect(center=(self.x - math.sin(math.radians(self.angle)) * 150,
                                           self.y - math.cos(math.radians(self.angle)) * 150))
        surf.blit(rot_beam, b_rect.topleft)

        glow = pygame.Surface((130, 200), pygame.SRCALPHA)
        g_col = (255, 230, 0, 80) if jump_height > 0 else ((0, 245, 255, 65) if self.is_boosting else (255, 20, 147, 55))
        pygame.draw.ellipse(glow, g_col, (15, 15, 100, 170))
        rot_glow = pygame.transform.rotozoom(glow, self.angle, scale)
        surf.blit(rot_glow, rot_glow.get_rect(center=(self.x, self.y - jump_height * 35)).topleft)

        rotated = pygame.transform.rotozoom(self.base_sprite, self.angle, scale)
        surf.blit(rotated, rotated.get_rect(center=(self.x, self.y - jump_height * 35)).topleft)

        if self.shield:
            pygame.draw.circle(surf, NEON_GREEN, (int(self.x), int(self.y - jump_height * 35)), int(88 * scale), 3)

class TrafficCar:
    def __init__(self, accent_color):
        self.lane = random.choice(LANES)
        self.x = float(self.lane)
        self.y = -180.0
        self.type = random.choice(["sedan", "truck", "racer"])
        if self.type == "truck":
            self.w, self.h = 84, 210
            self.speed_offset = random.uniform(4.5, 6.5)
            self.color = NEON_ORANGE
        elif self.type == "racer":
            self.w, self.h = 68, 136
            self.speed_offset = random.uniform(9.5, 12.5)
            self.color = accent_color
        else:
            self.w, self.h = 72, 140
            self.speed_offset = random.uniform(7.0, 9.0)
            self.color = NEON_YELLOW
        self.target_x = self.x

    def update(self, road_speed):
        self.y += (road_speed - self.speed_offset)
        if self.type == "racer" and random.random() < 0.012:
            self.target_x = float(random.choice(LANES))
        self.x += (self.target_x - self.x) * 0.06

    def draw(self, surf):
        rect = pygame.Rect(self.x - self.w // 2, self.y - self.h // 2, self.w, self.h)
        pygame.draw.rect(surf, (26, 24, 42), rect, border_radius=14)
        pygame.draw.rect(surf, self.color, rect, 3, border_radius=14)
        windshield = pygame.Rect(rect.left + 10, rect.top + 28, self.w - 20, 32)
        pygame.draw.rect(surf, (10, 12, 22), windshield, border_radius=6)
        pygame.draw.rect(surf, (255, 30, 30), (rect.left + 10, rect.bottom - 10, 18, 6), border_radius=2)
        pygame.draw.rect(surf, (255, 30, 30), (rect.right - 28, rect.bottom - 10, 18, 6), border_radius=2)

class PowerUp:
    def __init__(self):
        self.x = random.choice(LANES)
        self.y = -80.0
        self.kind = random.choice(["nitro", "shield", "energy", "coin"])
        self.pulse = 0.0

    def update(self, road_speed):
        self.y += road_speed * 0.9
        self.pulse += 0.14

    def draw(self, surf):
        r = 26 + math.sin(self.pulse) * 5
        colors = {"nitro": NEON_CYAN, "shield": NEON_GREEN, "energy": NEON_PURPLE, "coin": NEON_YELLOW}
        labels = {"nitro": "N", "shield": "S", "energy": "E", "coin": "$"}
        color = colors[self.kind]
        pygame.draw.circle(surf, color, (int(self.x), int(self.y)), int(r), 4)
        txt = font_ui.render(labels[self.kind], True, color)
        surf.blit(txt, (self.x - txt.get_width() // 2, self.y - txt.get_height() // 2))

def map_mouse_to_virtual(pos, win_w, win_h):
    vx = int(pos[0] * VIRTUAL_W / max(1, win_w))
    vy = int(pos[1] * VIRTUAL_H / max(1, win_h))
    return (vx, vy)

def main():
    global is_fullscreen, display_screen, current_track_idx

    # Cargar progreso guardado en disco (mantiene la fase desbloqueada aunque volvamos al menú)
    save_data = load_save()
    unlocked_stage = save_data["unlocked_stage"]
    selected_stage = save_data["current_stage"]
    best_score = save_data["best_score"]

    current_track_idx = STAGES_CONFIG[selected_stage]["default_music"]
    play_current_music()

    player = PlayerCar()
    traffic = []
    obstacles = []
    powerups = []
    particles = []
    emp_waves = []
    skids = []
    scenery = [SceneryObject("left") for _ in range(8)] + [SceneryObject("right") for _ in range(8)]

    road_offset = 0.0
    score = 0
    combo = 1
    combo_timer = 0
    shake = 0
    intro_banner_timer = 0
    game_state = "MENU"  # MENU, PLAYING, STAGE_CLEAR, CAMPAIGN_WIN, GAMEOVER

    distance_traveled = 0.0
    start_banner = None
    finish_banner = None

    # Botones del Menú Principal (Selector de Fase Guardada, Jugar, Sonidos, Salir)
    btn_stage_prev = UIButton((VIRTUAL_W // 2 - 360, 440, 80, 72), "<", NEON_YELLOW)
    btn_stage_next = UIButton((VIRTUAL_W // 2 + 280, 440, 80, 72), ">", NEON_YELLOW)
    btn_play_menu = UIButton((VIRTUAL_W // 2 - 240, 540, 480, 76), "INICIAR FASE", NEON_GREEN, "▶")
    btn_sound_menu = UIButton((VIRTUAL_W // 2 - 240, 635, 480, 72), "SONIDOS: ACTIVADOS", NEON_CYAN, "♪")
    btn_exit_menu = UIButton((VIRTUAL_W // 2 - 240, 725, 480, 72), "SALIR", NEON_RED, "✕")

    # Botones al Completar una Fase (elige cuándo empezar la siguiente o volver al menú manteniendo el guardado)
    btn_next_stage = UIButton((VIRTUAL_W // 2 - 260, 530, 520, 76), "EMPEZAR SIGUIENTE FASE", NEON_GREEN, "▶")
    btn_menu_from_clear = UIButton((VIRTUAL_W // 2 - 260, 625, 520, 74), "GUARDAR Y VOLVER AL MENÚ", NEON_CYAN, "⌂")

    # Botones de Game Over
    btn_play_over = UIButton((VIRTUAL_W // 2 - 240, 530, 480, 74), "REINTENTAR FASE", NEON_GREEN, "↻")
    btn_menu_over = UIButton((VIRTUAL_W // 2 - 240, 625, 480, 74), "VOLVER AL MENÚ", NEON_CYAN, "⌂")
    btn_exit_over = UIButton((VIRTUAL_W // 2 - 240, 720, 480, 74), "SALIR", NEON_RED, "✕")

    # Botones HUD superior derecho
    btn_hud_sound = UIButton((VIRTUAL_W - 430, 25, 400, 62), "SONIDOS: ON", NEON_CYAN, "♪")
    btn_hud_track = UIButton((VIRTUAL_W - 430, 100, 400, 62), "PISTA 1/8", NEON_PINK, "♫")
    btn_hud_exit = UIButton((VIRTUAL_W - 430, 175, 400, 58), "GUARDAR Y MENÚ", NEON_RED, "⌂")

    def persist_progress():
        write_save({
            "unlocked_stage": unlocked_stage,
            "current_stage": selected_stage,
            "best_score": best_score
        })

    def launch_stage(stage_num, keep_score=False):
        nonlocal player, score, combo, game_state, selected_stage, distance_traveled, start_banner, finish_banner, intro_banner_timer
        global current_track_idx
        play_sfx(SFX_CLICK)
        selected_stage = stage_num
        persist_progress()

        cfg = STAGES_CONFIG[selected_stage]
        current_track_idx = cfg["default_music"]
        play_current_music()

        distance_traveled = 0.0
        start_banner = RoadBanner(VIRTUAL_H - 360, f"SALIDA • {cfg['name']}", cfg["edge_main"])
        finish_banner = None
        intro_banner_timer = 150  # 2.5 segundos mostrando el cartel de inicio de fase

        if not keep_score:
            player = PlayerCar()
            score = 0
        else:
            player.x = VIRTUAL_W // 2
            player.y = VIRTUAL_H - 200
            player.vx = 0
            player.vy = 0
            player.nitro = 100.0
            player.energy = 100.0
            player.invulnerable = 60

        traffic.clear()
        obstacles.clear()
        powerups.clear()
        particles.clear()
        emp_waves.clear()
        skids.clear()
        combo = 1
        game_state = "PLAYING"

    running = True
    while running:
        clock.tick(60)
        keys = pygame.key.get_pressed()
        win_w, win_h = display_screen.get_size()
        v_mouse = map_mouse_to_virtual(pygame.mouse.get_pos(), win_w, win_h)

        cfg = STAGES_CONFIG[selected_stage]

        snd_label = "SONIDOS: ACTIVADOS" if sound_enabled else "SONIDOS: SILENCIO"
        snd_color = NEON_CYAN if sound_enabled else (150, 150, 170)
        for b in (btn_sound_menu, btn_hud_sound):
            b.text = snd_label
            b.color = snd_color

        track = MUSIC_TRACKS[current_track_idx]
        btn_hud_track.text = track["name"]
        btn_hud_track.color = track["color"]
        btn_play_menu.text = f"JUGAR {cfg['name'].split(':')[0]}"

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                persist_progress()
                running = False
            elif event.type == pygame.VIDEORESIZE and not is_fullscreen:
                display_screen = pygame.display.set_mode((event.w, event.h), pygame.RESIZABLE | pygame.DOUBLEBUF)
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_F11:
                    is_fullscreen = not is_fullscreen
                    display_screen = create_display(is_fullscreen)
                elif event.key == pygame.K_m:
                    next_music_track(1)
                elif event.key == pygame.K_b:
                    next_music_track(-1)
                elif event.key == pygame.K_n:
                    toggle_sound()
                elif event.key == pygame.K_ESCAPE:
                    if game_state in ["PLAYING", "STAGE_CLEAR", "CAMPAIGN_WIN", "GAMEOVER"]:
                        play_sfx(SFX_CLICK)
                        persist_progress()
                        game_state = "MENU"
                    else:
                        persist_progress()
                        running = False
                elif event.key == pygame.K_RETURN:
                    if game_state == "MENU":
                        launch_stage(selected_stage, False)
                    elif game_state == "STAGE_CLEAR":
                        launch_stage(selected_stage, True)
                    elif game_state == "CAMPAIGN_WIN":
                        launch_stage(1, False)
                    elif game_state == "GAMEOVER":
                        launch_stage(selected_stage, False)
                elif game_state == "MENU":
                    if event.key in [pygame.K_LEFT, pygame.K_a]:
                        play_sfx(SFX_CLICK)
                        selected_stage = max(1, selected_stage - 1)
                        persist_progress()
                    elif event.key in [pygame.K_RIGHT, pygame.K_d]:
                        if selected_stage < unlocked_stage:
                            play_sfx(SFX_CLICK)
                            selected_stage += 1
                            persist_progress()
                elif game_state == "PLAYING":
                    if event.key == pygame.K_q:
                        player.trigger_jump(particles)
                    elif event.key == pygame.K_e:
                        player.trigger_emp(emp_waves, obstacles, traffic, particles)
                    elif event.key == pygame.K_r:
                        player.trigger_slow_time()

            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if btn_hud_sound.is_hovered(v_mouse):
                    toggle_sound()
                elif btn_hud_track.is_hovered(v_mouse):
                    next_music_track(1)
                elif game_state == "PLAYING" and btn_hud_exit.is_hovered(v_mouse):
                    play_sfx(SFX_CLICK)
                    persist_progress()
                    game_state = "MENU"
                elif game_state == "MENU":
                    if btn_stage_prev.is_hovered(v_mouse) and selected_stage > 1:
                        play_sfx(SFX_CLICK)
                        selected_stage -= 1
                        persist_progress()
                    elif btn_stage_next.is_hovered(v_mouse) and selected_stage < unlocked_stage:
                        play_sfx(SFX_CLICK)
                        selected_stage += 1
                        persist_progress()
                    elif btn_play_menu.is_hovered(v_mouse):
                        launch_stage(selected_stage, False)
                    elif btn_sound_menu.is_hovered(v_mouse):
                        toggle_sound()
                    elif btn_exit_menu.is_hovered(v_mouse):
                        persist_progress()
                        running = False
                elif game_state == "STAGE_CLEAR":
                    if btn_next_stage.is_hovered(v_mouse):
                        launch_stage(selected_stage, True)
                    elif btn_menu_from_clear.is_hovered(v_mouse):
                        play_sfx(SFX_CLICK)
                        persist_progress()
                        game_state = "MENU"
                elif game_state == "CAMPAIGN_WIN":
                    if btn_next_stage.is_hovered(v_mouse):
                        launch_stage(1, False)
                    elif btn_menu_from_clear.is_hovered(v_mouse):
                        play_sfx(SFX_CLICK)
                        persist_progress()
                        game_state = "MENU"
                elif game_state == "GAMEOVER":
                    if btn_play_over.is_hovered(v_mouse):
                        launch_stage(selected_stage, False)
                    elif btn_menu_over.is_hovered(v_mouse):
                        play_sfx(SFX_CLICK)
                        persist_progress()
                        game_state = "MENU"
                    elif btn_exit_over.is_hovered(v_mouse):
                        persist_progress()
                        running = False

        # Dinámica de velocidad según la fase actual
        time_factor = 0.45 if player.slow_timer > 0 and game_state == "PLAYING" else 1.0
        base_speed = (cfg["base_speed"] + min(7.0, distance_traveled / 5000.0)) * time_factor
        road_speed = base_speed * (1.55 if player.is_boosting and game_state == "PLAYING" else 1.0)

        road_offset = (road_offset + road_speed) % 120
        for sc in scenery:
            sc.update(road_speed)

        if game_state == "PLAYING":
            player.update(keys, particles, skids)
            distance_traveled += road_speed
            score += int(road_speed * 0.25 * combo)
            if score > best_score:
                best_score = score

            if intro_banner_timer > 0:
                intro_banner_timer -= 1

            if start_banner is not None:
                start_banner.update(road_speed)
                if start_banner.y > VIRTUAL_H + 150:
                    start_banner = None

            if combo_timer > 0:
                combo_timer -= 1
            else:
                combo = 1

            goal_dist = cfg["goal_dist"]
            if distance_traveled >= goal_dist and finish_banner is None:
                finish_banner = RoadBanner(-160, f"META FINAL • {cfg['name']}", NEON_GREEN)

            # Generar obstáculos exclusivos de la fase antes de la meta
            if finish_banner is None and distance_traveled > 900:
                max_obs = min(6, 2 + selected_stage)
                if len(obstacles) < max_obs and random.random() < 0.032 + selected_stage * 0.005:
                    new_obs = Obstacle(cfg["obstacles"], selected_stage)
                    if all(abs(new_obs.y - o.y) > 260 for o in obstacles):
                        obstacles.append(new_obs)

                if len(traffic) < 5 and random.random() < 0.038:
                    new_car = TrafficCar(cfg["edge_main"])
                    if all(abs(new_car.y - c.y) > 260 or new_car.lane != c.lane for c in traffic) and                        all(abs(new_car.y - o.y) > 220 for o in obstacles):
                        traffic.append(new_car)

                if len(powerups) < 2 and random.random() < 0.016:
                    powerups.append(PowerUp())

            player_rect = pygame.Rect(player.x - 26, player.y - 56, 52, 112)
            near_miss_rect = player_rect.inflate(70, 45)
            is_airborne = player.jump_timer > 0

            for obs in obstacles[:]:
                obs.update(road_speed)
                obs_rect = obs.get_rect()

                if not is_airborne and player_rect.colliderect(obs_rect):
                    if obs.kind in ["oil", "ice_patch"]:
                        if player.slip_timer == 0:
                            player.slip_timer = 85 if obs.kind == "ice_patch" else 65
                            shake = 8
                    elif obs.kind == "sand_whirl":
                        player.vx += random.choice([-16, 16])
                        shake = 10
                    elif obs.is_lethal() and player.invulnerable == 0:
                        if player.shield:
                            play_sfx(SFX_SHIELD)
                            player.shield = False
                            player.invulnerable = 60
                            shake = 18
                            obstacles.remove(obs)
                        else:
                            play_sfx(SFX_CRASH)
                            shake = 28
                            for _ in range(60):
                                particles.append(Particle(player.x, player.y, random.uniform(-12, 12), random.uniform(-12, 12), NEON_PINK, 10, 40))
                            persist_progress()
                            game_state = "GAMEOVER"
                elif is_airborne and player_rect.colliderect(obs_rect) and not hasattr(obs, "jumped"):
                    obs.jumped = True
                    combo = min(15, combo + 1)
                    combo_timer = 180
                    score += 350 * combo

                if obs.y > VIRTUAL_H + 180:
                    obstacles.remove(obs)

            for car in traffic[:]:
                car.update(road_speed)
                car_rect = pygame.Rect(car.x - car.w // 2 + 6, car.y - car.h // 2 + 6, car.w - 12, car.h - 12)

                if not is_airborne and player_rect.colliderect(car_rect) and player.invulnerable == 0:
                    if player.shield:
                        play_sfx(SFX_SHIELD)
                        player.shield = False
                        player.invulnerable = 60
                        shake = 18
                        traffic.remove(car)
                        for _ in range(35):
                            particles.append(Particle(car.x, car.y, random.uniform(-9, 9), random.uniform(-9, 9), NEON_GREEN, 9, 30))
                    else:
                        play_sfx(SFX_CRASH)
                        shake = 28
                        for _ in range(60):
                            particles.append(Particle(player.x, player.y, random.uniform(-12, 12), random.uniform(-12, 12), NEON_PINK, 10, 40))
                        persist_progress()
                        game_state = "GAMEOVER"
                elif near_miss_rect.colliderect(car_rect) and not hasattr(car, "grazed"):
                    car.grazed = True
                    combo = min(15, combo + 1)
                    combo_timer = 160
                    score += 200 * combo

                if car.y > VIRTUAL_H + 220:
                    traffic.remove(car)

            for p in powerups[:]:
                p.update(road_speed)
                p_rect = pygame.Rect(p.x - 28, p.y - 28, 56, 56)
                if player_rect.colliderect(p_rect):
                    play_sfx(SFX_POWERUP)
                    if p.kind == "nitro":
                        player.nitro = min(100, player.nitro + 45)
                    elif p.kind == "shield":
                        player.shield = True
                    elif p.kind == "energy":
                        player.energy = min(100, player.energy + 50)
                    elif p.kind == "coin":
                        score += 600 * combo
                    for _ in range(20):
                        particles.append(Particle(p.x, p.y, random.uniform(-6, 6), random.uniform(-6, 6), NEON_CYAN, 7, 24))
                    powerups.remove(p)
                elif p.y > VIRTUAL_H + 100:
                    powerups.remove(p)

            # Cruce de la Meta Final de la Fase
            if finish_banner is not None:
                finish_banner.update(road_speed)
                if finish_banner.y >= player.y and not finish_banner.crossed:
                    finish_banner.crossed = True
                    play_sfx(SFX_VICTORY)
                    score += 3000 * selected_stage
                    if score > best_score:
                        best_score = score

                    if selected_stage < 5:
                        # Desbloquear y dejar guardada la siguiente fase automáticamente
                        selected_stage += 1
                        unlocked_stage = max(unlocked_stage, selected_stage)
                        persist_progress()
                        game_state = "STAGE_CLEAR"
                    else:
                        persist_progress()
                        game_state = "CAMPAIGN_WIN"

        for s in skids[:]:
            s.update(road_speed)
            if s.alpha <= 0:
                skids.remove(s)

        for pt in particles[:]:
            pt.update()
            if pt.life <= 0:
                particles.remove(pt)

        for w in emp_waves[:]:
            w.update()
            if not w.active:
                emp_waves.remove(w)

        # Renderizado con la paleta temática de la Fase Actual
        virtual_screen.fill(cfg["bg_color"])

        for sc in scenery:
            sc.draw(virtual_screen, cfg)

        pygame.draw.rect(virtual_screen, cfg["asphalt"], (ROAD_LEFT, 0, ROAD_WIDTH, VIRTUAL_H))
        pygame.draw.line(virtual_screen, cfg["edge_main"], (ROAD_LEFT, 0), (ROAD_LEFT, VIRTUAL_H), 7)
        pygame.draw.line(virtual_screen, cfg["edge_sub"], (ROAD_LEFT - 12, 0), (ROAD_LEFT - 12, VIRTUAL_H), 3)
        pygame.draw.line(virtual_screen, cfg["edge_main"], (ROAD_RIGHT, 0), (ROAD_RIGHT, VIRTUAL_H), 7)
        pygame.draw.line(virtual_screen, cfg["edge_sub"], (ROAD_RIGHT + 12, 0), (ROAD_RIGHT + 12, VIRTUAL_H), 3)

        for lx in [660, 860, 1060, 1260]:
            for ly in range(-120, VIRTUAL_H, 120):
                pygame.draw.rect(virtual_screen, (110, 110, 150), (lx - 3, ly + road_offset, 6, 65), border_radius=2)

        for s in skids:
            s.draw(virtual_screen)

        if start_banner is not None:
            start_banner.draw(virtual_screen)

        if finish_banner is not None:
            finish_banner.draw(virtual_screen)

        for obs in obstacles:
            obs.draw(virtual_screen)

        for p in powerups:
            p.draw(virtual_screen)

        for car in traffic:
            car.draw(virtual_screen)

        if game_state != "GAMEOVER":
            player.draw(virtual_screen)

        for w in emp_waves:
            w.draw(virtual_screen)

        for pt in particles:
            pt.draw(virtual_screen)

        # Cartel de Inicio de Fase al arrancar
        if game_state == "PLAYING" and intro_banner_timer > 0:
            box = pygame.Rect(VIRTUAL_W // 2 - 420, 260, 840, 120)
            s_box = pygame.Surface(box.size, pygame.SRCALPHA)
            pygame.draw.rect(s_box, (10, 12, 26, 215), s_box.get_rect(), border_radius=16)
            virtual_screen.blit(s_box, box.topleft)
            pygame.draw.rect(virtual_screen, cfg["edge_main"], box, 4, border_radius=16)

            t_start = font_subtitle.render(f"INICIO • {cfg['name']}", True, cfg["edge_main"])
            t_sub = font_small.render(cfg["subtitle"], True, WHITE)
            virtual_screen.blit(t_start, (VIRTUAL_W // 2 - t_start.get_width() // 2, 282))
            virtual_screen.blit(t_sub, (VIRTUAL_W // 2 - t_sub.get_width() // 2, 330))

        # Panel Izquierdo HUD
        panel_l = pygame.Rect(30, 25, 405, 325)
        pygame.draw.rect(virtual_screen, (16, 14, 32), panel_l, border_radius=12)
        pygame.draw.rect(virtual_screen, cfg["edge_main"], panel_l, 2, border_radius=12)

        stage_txt = font_ui.render(f"FASE {selected_stage}/5 | PTS: {score:07d}", True, WHITE)
        combo_txt = font_small.render(f"COMBO: x{combo}  |  RÉCORD: {best_score:07d}", True, NEON_YELLOW)
        virtual_screen.blit(stage_txt, (48, 38))
        virtual_screen.blit(combo_txt, (48, 70))

        prog = min(1.0, distance_traveled / max(1.0, cfg["goal_dist"]))
        pygame.draw.rect(virtual_screen, (35, 35, 55), (48, 102, 365, 20), border_radius=6)
        pygame.draw.rect(virtual_screen, NEON_GREEN, (48, 102, int(365 * prog), 20), border_radius=6)
        meta_lbl = font_small.render(f"META FASE {selected_stage}: {int(prog * 100)}% ({int(max(0, cfg['goal_dist'] - distance_traveled) / 10)}m)", True, NEON_GREEN)
        virtual_screen.blit(meta_lbl, (48, 126))

        pygame.draw.rect(virtual_screen, (35, 35, 55), (48, 158, 365, 18), border_radius=6)
        pygame.draw.rect(virtual_screen, NEON_CYAN, (48, 158, int(3.65 * player.nitro), 18), border_radius=6)
        virtual_screen.blit(font_small.render("NITRO [ESPACIO] | DERRAPE [SHIFT]", True, NEON_CYAN), (48, 180))

        pygame.draw.rect(virtual_screen, (35, 35, 55), (48, 210, 365, 18), border_radius=6)
        pygame.draw.rect(virtual_screen, NEON_PURPLE, (48, 210, int(3.65 * player.energy), 18), border_radius=6)
        virtual_screen.blit(font_small.render(f"ENERGÍA HABILIDADES: {int(player.energy)}%", True, NEON_PURPLE), (48, 232))

        q_col = NEON_YELLOW if (player.jump_cd == 0 and player.energy >= 25) else (100, 100, 120)
        e_col = NEON_CYAN if (player.emp_cd == 0 and player.energy >= 45) else (100, 100, 120)
        r_col = NEON_PINK if (player.slow_cd == 0 and player.energy >= 35) else (100, 100, 120)
        virtual_screen.blit(font_small.render("[Q] SALTO (25%)", True, q_col), (48, 265))
        virtual_screen.blit(font_small.render("[E] PULSO EMP (45%)", True, e_col), (225, 265))
        virtual_screen.blit(font_small.render("[R] CÁMARA LENTA (35%)", True, r_col), (48, 295))

        btn_hud_sound.draw(virtual_screen, v_mouse)
        btn_hud_track.draw(virtual_screen, v_mouse)
        if game_state == "PLAYING":
            btn_hud_exit.draw(virtual_screen, v_mouse)

        if game_state == "MENU":
            overlay = pygame.Surface((VIRTUAL_W, VIRTUAL_H), pygame.SRCALPHA)
            overlay.fill((8, 6, 18, 188))
            virtual_screen.blit(overlay, (0, 0))

            btn_hud_sound.draw(virtual_screen, v_mouse)
            btn_hud_track.draw(virtual_screen, v_mouse)

            t1 = font_title.render("NEON STREET RACER", True, NEON_CYAN)
            t2 = font_subtitle.render("WORLD TOUR • 5 FASES CON GUARDADO AUTOMÁTICO", True, NEON_PINK)
            c1 = font_small.render(f"PROGRESO GUARDADO: HASTA FASE {unlocked_stage} DE 5  |  RÉCORD: {best_score:07d}", True, NEON_GREEN)

            virtual_screen.blit(t1, (VIRTUAL_W // 2 - t1.get_width() // 2, 180))
            virtual_screen.blit(t2, (VIRTUAL_W // 2 - t2.get_width() // 2, 265))
            virtual_screen.blit(c1, (VIRTUAL_W // 2 - c1.get_width() // 2, 320))

            # Tarjeta del Selector de Fase Guardada
            card = pygame.Rect(VIRTUAL_W // 2 - 265, 425, 530, 100)
            pygame.draw.rect(virtual_screen, (20, 18, 42), card, border_radius=14)
            pygame.draw.rect(virtual_screen, cfg["edge_main"], card, 3, border_radius=14)

            st_name = font_ui.render(cfg["name"], True, cfg["edge_main"])
            st_desc = font_small.render(cfg["subtitle"], True, WHITE)
            virtual_screen.blit(st_name, (VIRTUAL_W // 2 - st_name.get_width() // 2, 442))
            virtual_screen.blit(st_desc, (VIRTUAL_W // 2 - st_desc.get_width() // 2, 482))

            if selected_stage > 1:
                btn_stage_prev.draw(virtual_screen, v_mouse)
            if selected_stage < unlocked_stage:
                btn_stage_next.draw(virtual_screen, v_mouse)

            btn_play_menu.draw(virtual_screen, v_mouse)
            btn_sound_menu.draw(virtual_screen, v_mouse)
            btn_exit_menu.draw(virtual_screen, v_mouse)

        elif game_state == "STAGE_CLEAR":
            overlay = pygame.Surface((VIRTUAL_W, VIRTUAL_H), pygame.SRCALPHA)
            overlay.fill((6, 24, 18, 195))
            virtual_screen.blit(overlay, (0, 0))

            btn_hud_sound.draw(virtual_screen, v_mouse)
            btn_hud_track.draw(virtual_screen, v_mouse)

            prev_cfg = STAGES_CONFIG[selected_stage - 1]
            next_cfg = STAGES_CONFIG[selected_stage]

            win_t = font_title.render(f"¡FINAL DE {prev_cfg['name'].split(':')[0]} SUPERADO!", True, NEON_GREEN)
            save_t = font_subtitle.render(f"✓ PROGRESO GUARDADO: {next_cfg['name']} DESBLOQUEADA", True, NEON_YELLOW)
            sub_t = font_small.render(f"Siguiente entorno: {next_cfg['subtitle']}", True, WHITE)

            virtual_screen.blit(win_t, (VIRTUAL_W // 2 - win_t.get_width() // 2, 250))
            virtual_screen.blit(save_t, (VIRTUAL_W // 2 - save_t.get_width() // 2, 355))
            virtual_screen.blit(sub_t, (VIRTUAL_W // 2 - sub_t.get_width() // 2, 415))

            btn_next_stage.text = f"EMPEZAR {next_cfg['name'].split(':')[0]}"
            btn_next_stage.draw(virtual_screen, v_mouse)
            btn_menu_from_clear.draw(virtual_screen, v_mouse)

        elif game_state == "CAMPAIGN_WIN":
            overlay = pygame.Surface((VIRTUAL_W, VIRTUAL_H), pygame.SRCALPHA)
            overlay.fill((22, 10, 32, 198))
            virtual_screen.blit(overlay, (0, 0))

            btn_hud_sound.draw(virtual_screen, v_mouse)
            btn_hud_track.draw(virtual_screen, v_mouse)

            win_t = font_title.render("¡CAMPEÓN DEL CIRCUITO OMEGA!", True, NEON_YELLOW)
            sub_t = font_subtitle.render(f"HAS COMPLETADO LAS 5 FASES • PUNTUACIÓN: {score:07d}", True, NEON_GREEN)

            virtual_screen.blit(win_t, (VIRTUAL_W // 2 - win_t.get_width() // 2, 270))
            virtual_screen.blit(sub_t, (VIRTUAL_W // 2 - sub_t.get_width() // 2, 380))

            btn_next_stage.text = "REINICIAR DESDE FASE 1"
            btn_next_stage.draw(virtual_screen, v_mouse)
            btn_menu_from_clear.draw(virtual_screen, v_mouse)

        elif game_state == "GAMEOVER":
            overlay = pygame.Surface((VIRTUAL_W, VIRTUAL_H), pygame.SRCALPHA)
            overlay.fill((25, 4, 14, 195))
            virtual_screen.blit(overlay, (0, 0))

            btn_hud_sound.draw(virtual_screen, v_mouse)
            btn_hud_track.draw(virtual_screen, v_mouse)

            go = font_title.render("¡VEHÍCULO DESTRUIDO!", True, NEON_PINK)
            sc = font_subtitle.render(f"{cfg['name']}  |  SCORE: {score:07d}", True, NEON_YELLOW)
            sv = font_small.render("Tu progreso hasta esta fase sigue guardado", True, NEON_CYAN)

            virtual_screen.blit(go, (VIRTUAL_W // 2 - go.get_width() // 2, 270))
            virtual_screen.blit(sc, (VIRTUAL_W // 2 - sc.get_width() // 2, 375))
            virtual_screen.blit(sv, (VIRTUAL_W // 2 - sv.get_width() // 2, 430))

            btn_play_over.draw(virtual_screen, v_mouse)
            btn_menu_over.draw(virtual_screen, v_mouse)
            btn_exit_over.draw(virtual_screen, v_mouse)

        ox = random.randint(-shake, shake) if shake > 0 else 0
        oy = random.randint(-shake, shake) if shake > 0 else 0
        if shake > 0:
            shake -= 1

        if (win_w, win_h) == (VIRTUAL_W, VIRTUAL_H):
            display_screen.blit(virtual_screen, (ox, oy))
        else:
            scaled_surf = pygame.transform.smoothscale(virtual_screen, (win_w, win_h))
            display_screen.blit(scaled_surf, (ox, oy))

        pygame.display.flip()

    pygame.quit()

if __name__ == "__main__":
    main()
