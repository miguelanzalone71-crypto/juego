import wave
import struct
import math
import random
import os

SAMPLE_RATE = 44100

def generate_track(filename, genre):
    duration = 14
    num_samples = SAMPLE_RATE * duration
    
    scales = {
        "synthwave": [110.0, 130.81, 146.83, 164.81, 196.0, 220.0],
        "rock": [82.41, 98.0, 110.0, 123.47, 146.83, 164.81],
        "electro": [65.41, 77.78, 98.0, 116.54, 130.81, 155.56],
        "lofi": [130.81, 164.81, 196.0, 246.94, 293.66, 329.63],
        "phonk": [55.0, 65.41, 73.42, 82.41, 87.31, 98.0],
        "jazz": [146.83, 174.61, 220.0, 261.63, 329.63, 392.0],
        "eurobeat": [146.83, 164.81, 196.0, 220.0, 261.63, 293.66],
        "ambient": [110.0, 164.81, 220.0, 246.94, 329.63, 440.0]
    }
    
    bpms = {
        "synthwave": 122, "rock": 145, "electro": 136, "lofi": 84,
        "phonk": 130, "jazz": 115, "eurobeat": 158, "ambient": 90
    }
    
    bpm = bpms[genre]
    beat_samples = int(SAMPLE_RATE * 60 / bpm)
    notes = scales[genre]
    
    random.seed(genre + "_hd")
    melody = [random.choice(notes) * random.choice([1, 2]) for _ in range(32)]
    
    with wave.open(filename, 'w') as wav_file:
        wav_file.setnchannels(1)
        wav_file.setsampwidth(2)
        wav_file.setframerate(SAMPLE_RATE)
        
        frames = bytearray()
        for i in range(num_samples):
            t = i / SAMPLE_RATE
            beat_idx = (i // (beat_samples // 2)) % len(melody)
            beat_pos = (i % beat_samples) / beat_samples
            sub_pos = ((i * 2) % beat_samples) / beat_samples
            freq = melody[beat_idx]
            
            if genre == "synthwave":
                bass = 0.28 * (2 * ((t * (freq / 2)) % 1) - 1)
                lead = 0.22 * math.sin(2 * math.pi * freq * t) + 0.1 * math.sin(2 * math.pi * freq * 1.005 * t)
                kick = 0.42 * math.sin(2 * math.pi * (125 * math.exp(-beat_pos * 12)) * t) if beat_pos < 0.3 else 0
                val = bass + lead + kick
            elif genre == "rock":
                raw = math.sin(2 * math.pi * freq * t) + 0.55 * math.sin(2 * math.pi * (freq * 1.5) * t)
                guitar = max(-0.38, min(0.38, raw * 2.8))
                snare = (random.random() * 2 - 1) * 0.28 * math.exp(-beat_pos * 16) if (i // beat_samples) % 2 == 1 else 0
                kick = 0.35 * math.sin(2 * math.pi * (110 * math.exp(-beat_pos * 14)) * t) if (i // beat_samples) % 2 == 0 else 0
                val = guitar + snare + kick
            elif genre == "electro":
                sub = 0.45 * math.sin(2 * math.pi * (freq / 2) * t)
                sq = 0.18 if math.sin(2 * math.pi * freq * 2 * t) > 0 else -0.18
                hat = (random.random() * 2 - 1) * 0.14 * math.exp(-sub_pos * 22)
                val = sub + sq + hat
            elif genre == "lofi":
                vibrato = math.sin(2 * math.pi * 4.5 * t) * 1.6
                chord = 0.28 * math.sin(2 * math.pi * (freq + vibrato) * t) + 0.18 * math.sin(2 * math.pi * (freq * 1.25) * t)
                crackle = (random.random() * 2 - 1) * 0.025 if random.random() > 0.96 else 0
                val = chord + crackle
            elif genre == "phonk":
                bass808 = 0.5 * math.sin(2 * math.pi * (freq * 0.5) * t) * math.exp(-beat_pos * 3)
                cowbell = 0.28 * (math.sin(2 * math.pi * 540 * t) + math.sin(2 * math.pi * 800 * t)) * math.exp(-sub_pos * 18)
                val = max(-0.8, min(0.8, (bass808 + cowbell) * 1.3))
            elif genre == "jazz":
                walk = 0.3 * math.sin(2 * math.pi * (freq * 0.5) * t)
                rhodes = 0.25 * math.sin(2 * math.pi * freq * t) + 0.15 * math.sin(2 * math.pi * (freq * 1.5) * t)
                brush = (random.random() * 2 - 1) * 0.08 * math.exp(-sub_pos * 12)
                val = walk + rhodes + brush
            elif genre == "eurobeat":
                arp_mult = [1, 1.5, 2, 1.5][int(sub_pos * 4) % 4]
                lead = 0.28 * (2 * ((t * (freq * arp_mult)) % 1) - 1)
                kick = 0.4 * math.sin(2 * math.pi * (140 * math.exp(-beat_pos * 15)) * t)
                val = lead + kick
            else:
                pad1 = 0.25 * math.sin(2 * math.pi * freq * t)
                pad2 = 0.22 * math.sin(2 * math.pi * (freq * 1.498) * t)
                shimmer = 0.12 * math.sin(2 * math.pi * (freq * 2.003) * t) * (0.5 + 0.5 * math.sin(t * 2))
                val = pad1 + pad2 + shimmer

            sample = int(max(-32767, min(32767, val * 28000)))
            frames.extend(struct.pack('<h', sample))
            
        wav_file.writeframes(frames)

def ensure_music_assets():
    os.makedirs("assets/music", exist_ok=True)
    genres = ["synthwave", "rock", "electro", "lofi", "phonk", "jazz", "eurobeat", "ambient"]
    for g in genres:
        path = f"assets/music/{g}.wav"
        if not os.path.exists(path):
            generate_track(path, g)

if __name__ == "__main__":
    ensure_music_assets()
