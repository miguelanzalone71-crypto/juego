# NEON STREET RACER: 5 STAGES WORLD TOUR HD

Versión con **5 Fases temáticas distintas**, cada una con su **Arco de Inicio**, **Línea de Meta Final**, cambio total de ambientación/colores/obstáculos y **Guardado Automático Persistente** (`save_progress.json`) para que nunca pierdas tu fase desbloqueada aunque vuelvas al menú o cierres el juego.

## Las 5 Fases del Circuito
1. **Fase 1 - Distrito Cyber Neón:** Autopista nocturna rosa/cian con barreras y manchas de aceite.
2. **Fase 2 - Puerto Industrial Tóxico:** Ambientación verde/amarilla con puertas láser intermitentes y barreras.
3. **Fase 3 - Cañón Solar Desértico:** Montañas rocosas naranjas, drones patrulla y remolinos de arena que empujan el coche.
4. **Fase 4 - Autopista Ártica Criogénica:** Glaciares azules, placas de hielo deslizantes, láseres y drones.
5. **Fase 5 - Núcleo Omega (Final):** Fortaleza orbital púrpura/roja con máxima velocidad y todos los obstáculos combinados.

## Guardado y Control de Fases
- Al cruzar la **Meta Final** de una fase, la siguiente se desbloquea y guarda automáticamente en `save_progress.json`.
- Puedes elegir **empezar la siguiente fase al instante** o pulsar **`GUARDAR Y VOLVER AL MENÚ`** para retomarla cuando quieras desde el selector de fases (`<` / `>`).

## Ejecución
```bash
pip install -r requirements.txt
python main.py
```
